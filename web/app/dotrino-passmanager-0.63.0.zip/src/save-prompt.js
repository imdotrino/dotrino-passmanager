// El aviso de «¿la guardo?» que sale DESPUÉS de entrar, en la página siguiente.
//
// Corre en el origen de la extensión (es un iframe suyo, incrustado en la página), y de
// ahí sale toda su seguridad: el clic que escribe en la bóveda nace aquí, no en el
// sitio, así que llega al service worker con origen `chrome-extension://` y pasa por la
// misma puerta que el popup. La página no puede pulsarlo, ni leerlo, ni fingirlo.
//
// Tres preguntas, y en este orden: **dónde** se guarda (una entrada nueva o una de las
// que ya hay), **qué** se escribe (una casilla por dato) y entonces sí, guardar.
//
// **La contraseña no pasa por aquí.** Lo capturado vive en el service worker; esta
// pantalla enseña de qué sitio y de qué usuario se trata, y qué se va a escribir — la
// contraseña, tapada.

import { t, pickLang, kindLabel, errorText } from './i18n.js'
import { hostApprovals } from './approval.js'
import { mountAccountSwitch } from './account-switch.js'
import { askWorker as ask } from './page.js'

const lang = pickLang()

// EL SITIO Y EL USUARIO no vienen de la página: los trae `pending-detail`, que solo se
// contesta al origen de la extensión. Venían por la URL del iframe, y eso obligaba a que
// el service worker se los diera antes al content script — o sea, a la página. Un acceso
// que te deja en otro host habría enseñado ahí un usuario que no es de ese sitio, y por
// eso el aviso estaba acotado al mismo host. Ahora no hace falta acotarlo por eso.
let host = ''
let user = ''

const $ = (id) => document.getElementById(id)

document.documentElement.lang = lang
$('save').textContent = t(lang, 'save')
$('no').textContent = t(lang, 'notNow')


const post = (msg) => { try { window.parent.postMessage({ _dotrino: msg.op, ...msg }, '*') } catch (_) {} }

/** Cerrarse es pedirle al content script que quite el iframe: él es quien lo montó. */
const close = () => post({ op: 'close-save-prompt' })

/**
 * Y decirle cuánto ocupa. El iframe lo dibuja la página, así que su alto no puede salir
 * de su propio CSS: sin esto la lista de campos se corta por abajo.
 */
const measure = () => {
  // Los 2 px son el borde del cuerpo.
  post({ op: 'size-save-prompt', h: Math.ceil(document.documentElement.getBoundingClientRect().height) + 2 })
}
const resize = () => {
  // DOS medidas. La de ahora es la que hace visible el aviso (ui.js), y hace falta: un
  // iframe oculto no recibe fotogramas, así que esperando solo al siguiente no se
  // mostraba nunca. La del fotograma siguiente, con la lista ya colocada, corrige el alto:
  // medida solo antes, sale corta y el aviso aparece con barra de scroll.
  measure()
  requestAnimationFrame(measure)
}

// Ver lo que ya estaba guardado («esto cambia, antes decía…») lo saca de la bóveda, y la
// bóveda pregunta antes (§3.3.1). La pregunta se dibuja dentro de este mismo iframe: es
// del origen de la extensión, y así el aviso no pierde lo que el usuario ya marcó.
hostApprovals({ resize })

// EN QUÉ CUENTA: cambiarla es cambiar de perfil, y lo de abajo se vuelve a pedir a la
// bóveda de la cuenta elegida (`account-switch.js`).
const cuenta = mountAccountSwitch($('account'), {
  ask, lang, resize, testid: 'save-prompt-account',
  onChange: () => load({ cambio: true }),
  onError: fail,
})

/** «hace 3 días». Para distinguir dos entradas que por fuera se ven iguales. */
function ago (ts) {
  if (!ts) return ''
  const s = Math.round((ts - Date.now()) / 1000)
  const rtf = new Intl.RelativeTimeFormat(lang, { numeric: 'auto' })
  for (const [unit, secs] of [['year', 31536000], ['month', 2592000], ['day', 86400], ['hour', 3600], ['minute', 60]]) {
    if (Math.abs(s) >= secs) return rtf.format(Math.round(s / secs), unit)
  }
  return rtf.format(Math.round(s), 'second')
}

function fail (e) {
  $('err').textContent = errorText(lang, e)
  $('err').hidden = false
  for (const b of document.querySelectorAll('button')) b.disabled = false
  // Pero «Guardar» sigue a las casillas: con nada marcado —o sin haber cargado nada— no
  // hay qué guardar.
  syncButtons()
  resize()
}

// --- dónde y qué ---------------------------------------------------------------
//
// DÓNDE, porque una página no tiene un ancla única: puedes tener dos contraseñas del
// mismo correo y que una ya no sirva. El gestor no elige por el usuario cuál se pisa —
// enseña las que hay, con la que más se parece primero, y también la salida de crear
// una nueva.
//
// QUÉ, con una casilla por dato: casi siempre hay uno que quieres y otro que no, y sin
// las casillas la única salida era «ahora no» y volver a escribirlo todo en la bóveda.
//
// La frontera de lo privado está en el medio: la LISTA de candidatas es pública (es lo
// que se ve sin la llave), pero saber si un dato *cambia* obliga a abrir lo guardado.
// QUÉ cambia se sabe sin abrir nada: la bóveda manda un resumen de cada campo y aquí se
// compara con lo escrito (§4.0.2). Lo que NO se enseña es qué había antes: para eso habría
// que abrir la entrada, y este aviso no es sitio para sacar de la bóveda un dato privado
// que nadie pidió (dueño, 2026-08-29). Había un botón «Ver qué cambia» y se quitó.

let detail = null
let target = ''        // '' = una entrada nueva
let picked = new Set()
/** El nombre que llevará la entrada nueva. `null` = todavía no se ha decidido. */
let nuevoNombre = null
/** Qué entrada se está renombrando ahora mismo. */
let editando = ''

/** Las filas de lo que se escribiría en el destino elegido. */
function rowsFor (id) {
  const diff = id ? detail.diffs?.[id] : null
  // Los NOMBRES de lo que lleva la entrada elegida vienen en la vista pública, sin abrir
  // nada (§4.0.2): con eso ya se sabe si un dato **existe** ahí, que es lo que separa
  // «nuevo» de «cambia». Lo que sigue sin saberse es si vale lo mismo, y eso lo dicen los
  // resúmenes (`diffs`).
  const dentro = id ? detail.candidates?.find((c) => c.id === id) : null
  const keys = Array.isArray(dentro?.fieldKeys) ? dentro.fieldKeys : null
  return detail.typed
    .map((f) => {
      const d = diff?.find((x) => x.key === f.key)
      // Sin destino, todo es nuevo. Con destino y sin diff, lo que digan los nombres; y
      // si tampoco hay nombres, no se sabe: no se dice nada en vez de decir algo falso.
      const status = !id
        ? 'new'
        : d ? d.status : (keys ? (keys.includes(f.key) ? 'changed' : 'new') : 'unknown')
      return { ...f, status }
    })
    .filter((r) => r.status !== 'same')
}

/**
 * EL NOMBRE DE PARTIDA de la entrada nueva: el mismo que se calcularía del contenido
 * (§5), para que lo que se ve en el campo sea lo que va a quedar si no se toca.
 *
 * Y por eso **solo se guarda si se cambia**: dejar la sugerencia escrita congelaría un
 * nombre que hasta ahora se calculaba solo. El nombre puesto es una decisión; esto es la
 * suposición de siempre, enseñada por adelantado para poder corregirla.
 */
function sugerido () {
  if (user) return user
  const publicos = (detail?.typed || []).filter((f) => !f.secret && f.value)
  const correo = publicos.find((f) => f.key === 'email')
  return String((correo || publicos[0])?.value || host || '')
}

/** El nombre que se guardará, o nada si es la sugerencia sin tocar. */
function nombreElegido () {
  const puesto = (nuevoNombre ?? '').trim()
  return puesto && puesto !== sugerido().trim() ? puesto : ''
}

/** Cómo se llama esta fila: los campos libres, como los llama el sitio. */
const labelOf = (row) => row.label || kindLabel(lang, row.key)

/**
 * La línea de debajo de la marca: DÓNDE va a parar esto.
 *
 * Sigue a la selección de abajo (dueño, 2026-08-28): con una entrada elegida dice cuál
 * es; con una nueva, el usuario que se acaba de escribir. Y siempre el sitio, que es lo
 * que ata todo esto a la página que tienes delante.
 */
function renderWho () {
  const r = detail?.candidates?.find(c => c.id === target)
  const quien = r ? (r.hint || r.title) : (user || t(lang, 'noUser'))
  $('who').textContent = [quien, host].filter(Boolean).join(' · ')
}

/**
 * EL LÁPIZ que deja renombrar una entrada, al lado de su nombre (dueño, 2026-08-29).
 *
 * El nombre de una entrada se calculaba de su contenido —el usuario, el correo, el primer
 * campo—, que sirve para no dejar filas en blanco pero es una suposición: con dos cuentas
 * del mismo sitio dice lo mismo de las dos.
 */
function pencil (id) {
  const b = document.createElement('button')
  b.type = 'button'
  b.className = 'pencil'
  b.dataset.testid = `save-prompt-rename-${id}`
  b.title = t(lang, 'renameEntry')
  b.setAttribute('aria-label', t(lang, 'renameEntry'))
  b.textContent = '✎'
  b.addEventListener('click', (ev) => {
    ev.preventDefault()
    ev.stopPropagation()
    editando = id
    renderTargets()
    resize()
  })
  return b
}

/**
 * El campo donde se escribe el nombre, con su VISTO al lado.
 *
 * Enter y salir del campo ya guardaban, y siguen guardando; lo que no hacían era
 * **decirse** (dueño, 2026-08-29: *«no se sabe dónde presionar para confirmar»*). Un
 * atajo que solo conoce quien lo escribió no es un atajo, es un secreto.
 *
 * El de la entrada NUEVA no lleva visto, y es a propósito: ahí no hay nada que confirmar
 * —el nombre se aplica al guardar, con el botón de abajo—, y un visto que no hace nada
 * enseña a desconfiar del que sí.
 */
function nameInput (id, valor) {
  const caja = document.createElement('input')
  caja.type = 'text'
  caja.className = 'newname'
  caja.value = valor || ''
  caja.placeholder = t(lang, 'entryName')
  caja.dataset.testid = id ? `save-prompt-name-${id}` : 'save-prompt-new-name'
  if (!id) {
    caja.addEventListener('input', () => { nuevoNombre = caja.value })
    caja.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') ev.preventDefault() })
    return { fila: caja, caja }
  }
  let cerrado = false
  const guardar = async (aplicar) => {
    if (cerrado) return
    cerrado = true
    editando = ''
    if (aplicar) {
      try {
        await ask('rename', { id, name: caja.value })
        detail = await ask('pending-detail')
      } catch (e) { fail(e) }
    }
    renderTargets()
    renderWho()
    resize()
  }
  caja.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') { ev.preventDefault(); guardar(true) }
    if (ev.key === 'Escape') { ev.preventDefault(); guardar(false) }
  })
  caja.addEventListener('blur', () => guardar(true))

  const listo = document.createElement('button')
  listo.type = 'button'
  listo.className = 'ok'
  listo.dataset.testid = `save-prompt-name-ok-${id}`
  listo.title = t(lang, 'confirmName')
  listo.setAttribute('aria-label', t(lang, 'confirmName'))
  listo.textContent = '✓'
  listo.addEventListener('click', (ev) => { ev.preventDefault(); guardar(true) })

  const fila = document.createElement('span')
  fila.className = 'editing'
  fila.append(caja, listo)
  // El PAR, como el otro `return` de arriba: quien llama necesita el contenedor para
  // colgarlo y el campo para enfocarlo. Devolver solo el contenedor pintaba «undefined»
  // en la fila —el destructurado no encontraba nada— y así lo vio el dueño.
  return { fila, caja }
}

function renderTargets () {
  const ul = $('targets')
  ul.textContent = ''
  if (!detail.candidates.length) { $('where').hidden = true; return }
  $('where').hidden = false
  $('whereLabel').textContent = t(lang, 'saveWhere')

  // La etiqueta «se parece» va SOLO si hay UNA que se parezca. Con dos, ninguna se
  // distingue de la otra por ahí, y ponérsela a la primera sería señalar a una al azar:
  // lo que las separa es la fecha, que va en cada una.
  const unaSola = detail.candidates.filter((c) => c.similar).length === 1
  let yaMarcada = !unaSola
  const opciones = [
    { id: '', label: t(lang, 'newEntry'), when: '', tag: '' },
    ...detail.candidates.map((c) => {
      const marca = c.similar && !yaMarcada
      if (marca) yaMarcada = true
      return {
        id: c.id,
        label: c.hint || c.title || t(lang, 'noUser'),
        // El título solo si dice algo que no esté ya arriba: casi siempre es el propio
        // sitio, y repetirlo se comía el espacio de la fecha, que es lo que distingue
        // dos entradas iguales por fuera.
        when: [c.title && c.title !== host ? c.title : '', ago(c.updatedAt)].filter(Boolean).join(' · '),
        tag: marca ? t(lang, 'mostSimilar') : (c.anywhere ? t(lang, 'anywhereEntry') : ''),
      }
    }),
  ]

  for (const o of opciones) {
    const li = document.createElement('li')
    li.dataset.testid = 'save-prompt-target'
    li.dataset.id = o.id

    const label = document.createElement('label')
    label.className = 't'

    const radio = document.createElement('input')
    radio.type = 'radio'
    radio.name = 'target'
    radio.value = o.id
    radio.checked = o.id === target
    radio.dataset.testid = o.id ? `save-prompt-target-${o.id}` : 'save-prompt-target-new'
    radio.addEventListener('change', () => {
      target = o.id
      // La lista se repinta también: al elegir «una entrada nueva» su fila pasa a ser el
      // campo donde se le escribe el nombre.
      renderTargets()
      renderWho()
      renderFields()
    })

    // Escribiendo el nombre: de la entrada nueva cuando está elegida, o de la que se está
    // renombrando. En los dos casos el campo se lleva la fila.
    const escribiendo = (!o.id && o.id === target) || (o.id && o.id === editando)
    if (escribiendo) {
      const { fila, caja } = nameInput(o.id, o.id ? o.label : (nuevoNombre ?? sugerido()))
      label.append(radio, fila)
      li.append(label)
      ul.append(li)
      if (o.id) requestAnimationFrame(() => { caja.focus(); caja.select() })
      continue
    }

    const who = document.createElement('span')
    who.className = 'who2'
    who.textContent = o.label

    const lapiz = o.id ? pencil(o.id) : null

    const when = document.createElement('span')
    when.className = 'when'
    when.textContent = o.when

    label.append(radio, who, ...(lapiz ? [lapiz] : []), when)
    if (o.tag) {
      const tag = document.createElement('span')
      tag.className = 'tag'
      tag.textContent = o.tag
      label.append(tag)
    }
    li.append(label)
    ul.append(li)
  }

}

function renderFields () {
  const ul = $('fields')
  ul.textContent = ''
  const rows = rowsFor(target)
  $('fieldsLabel').textContent = t(lang, 'fieldsLabel')
  $('fieldsLabel').hidden = !rows.length
  // Marcadas las que se pidieron: al enviar un formulario, todas; al pulsar el botón de
  // un campo, ese. Los demás quedan a mano, sin marcar.
  picked = new Set(rows.filter((r) => r.pick !== false).map((r) => r.key))

  for (const row of rows) {
    const li = document.createElement('li')
    li.dataset.testid = 'save-prompt-field'
    li.dataset.field = row.key

    const label = document.createElement('label')
    label.className = 'f'

    const box = document.createElement('input')
    box.type = 'checkbox'
    box.checked = picked.has(row.key)
    box.dataset.testid = `save-prompt-pick-${row.key}`
    box.addEventListener('change', () => {
      if (box.checked) picked.add(row.key)
      else picked.delete(row.key)
      syncButtons()
    })

    const k = document.createElement('span')
    k.className = 'k'
    k.textContent = labelOf(row)
    k.title = labelOf(row)

    const v = document.createElement('span')
    v.className = 'v'
    // La contraseña llega en `null` a propósito: no sale del service worker.
    v.textContent = row.secret ? t(lang, 'hidden') : row.value
    v.dataset.testid = `save-prompt-value-${row.key}`
    if (!row.secret) v.title = row.value

    const kv = document.createElement('span')
    kv.className = 'kv'
    kv.append(k, v)

    label.append(box, kv)
    if (row.status !== 'unknown') {
      const tag = document.createElement('span')
      tag.className = 'tag' + (row.status === 'changed' ? ' changed' : '')
      tag.textContent = t(lang, row.status === 'changed' ? 'fieldChanged' : 'fieldNew')
      label.append(tag)
    }
    li.append(label)

    // Qué había antes, para que «cambia» diga QUÉ cambia. De la contraseña, nada.
    ul.append(li)
  }

  syncButtons()
  resize()
}

function syncButtons () {
  $('save').textContent = target
    ? t(lang, 'updateInto')
    : (detail?.candidates?.length ? t(lang, 'saveAsNew') : t(lang, 'save'))
  const nada = picked.size === 0
  $('save').disabled = nada
  $('save').title = nada ? t(lang, 'pickNothing') : ''
}

// Lo capturado caduca a los 5 minutos (`PENDING_TTL_MS` en background.js). Pasado eso
// no queda nada que guardar, así que el aviso se cierra solo.
let expiryTimer = null
function scheduleExpiry (expiresAt) {
  clearTimeout(expiryTimer)
  if (!Number.isFinite(expiresAt)) return
  expiryTimer = setTimeout(close, Math.max(0, expiresAt - Date.now()))
}

/** `cambio`: se vuelve a cargar porque se eligió otra cuenta, no porque se abra el aviso. */
async function load ({ cambio = false } = {}) {
  $('err').hidden = true
  detail = await ask('pending-detail')
  if (!detail?.has) return close()
  scheduleExpiry(detail.expiresAt)
  nuevoNombre = null
  editando = ''
  // De quién y de dónde es lo que se acaba de escribir. Llega aquí, no por la URL.
  host = detail.host || ''
  user = detail.username || ''
  // Preseleccionada, la que más se parece — que es la que el usuario querría pisar el
  // 90 % de las veces. Si ninguna se parece, una entrada nueva: no se pisa por defecto
  // algo que no se sabe si es lo mismo.
  // A DÓNDE va, si el usuario no toca nada.
  //
  // Solo cuando **una sola** entrada se parece. Si se parecen dos —dos cuentas con el
  // mismo usuario, dos fichas de datos del mismo sitio— «la que más se parece» no existe,
  // y elegir la primera es escribir encima de un registro al azar. Ahí no se adivina: se
  // deja marcada la entrada nueva y que el usuario diga cuál (dueño, 2026-08-29:
  // *«los records deben tener un id único que no se muestra, no se mergean así»*).
  const parecidas = detail.candidates.filter((c) => c.similar)
  target = parecidas.length === 1 ? parecidas[0].id : ''

  // Nada que añadir ni que cambiar: no se molesta al usuario con un aviso que solo puede
  // contestar que sí a lo que ya tenía igual.
  //
  // Salvo tras cambiar de cuenta: ahí el usuario está mirando, y descartar lo apuntado
  // porque ESTA cuenta ya lo tiene le quitaría la opción de volver a la otra. Se enseña
  // sin filas y con «Guardar» deshabilitado.
  if (!cambio && !rowsFor(target).length) {
    try { await ask('dismiss-pending') } catch (_) {}
    return close()
  }

  await cuenta.refresh()
  renderTargets()
  renderWho()
  renderFields()
  if (!cambio) $('save').focus()
}

async function save () {
  for (const b of document.querySelectorAll('button')) b.disabled = true
  try {
    await ask('save-pending', {
      ...(target ? { id: target } : {}),
      pick: [...picked],
      // El nombre escrito en la fila de «una entrada nueva», si es ahí donde va y si de
      // verdad se escribió: la sugerencia sin tocar no se guarda (ver `sugerido`).
      ...(!target && nombreElegido() ? { name: nombreElegido() } : {}),
    })
    close()
  } catch (e) { fail(e) }
}

$('save').onclick = save
$('no').onclick = async () => {
  // Descartar BORRA lo capturado. Si se quedara ahí, un «ahora no» dejaría una
  // contraseña en claro esperando en la memoria del navegador sin que nadie la pidiera.
  try { await ask('dismiss-pending') } catch (_) {}
  close()
}

// Sin `resize()` aquí: medirse es lo que hace visible el aviso (ui.js), y todavía no se
// sabe si hay algo que enseñar. Lo hace `renderFields`, o `fail`, o una aprobación.
load().catch(fail)
