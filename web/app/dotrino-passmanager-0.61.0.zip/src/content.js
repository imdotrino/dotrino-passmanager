// Content script: marca los campos donde el gestor puede ayudar, y wait.
//
// **No autocompleta nada.** No tiene la bóveda ni la llave: le pregunta al service
// worker qué hay para ESTE sitio y solo pide una credencial cuando el usuario elige
// una en el modal. Rellenar es siempre un acto suyo, sobre un campo concreto.

// Un content script MV3 no se carga como módulo: la detección y la UI entran por
// import dinámico desde `web_accessible_resources`.
const mods = Promise.all([
  import(chrome.runtime.getURL('src/detect.js')),
  import(chrome.runtime.getURL('src/ui.js')),
  import(chrome.runtime.getURL('src/i18n.js')),
]).then(([detect, ui, i18n]) => ({ detect, ui, i18n }))

// El idioma sale del navegador y NO de `localStorage`: aquí ese almacén es el de la
// PÁGINA, no el nuestro, y no se lee lo que es del sitio ni para esto.
const lang = (navigator.language || 'es').toLowerCase().startsWith('en') ? 'en' : 'es'
const t = (key, ...args) => (cache.i18n ? cache.i18n.t(lang, key, ...args) : '')

let lastForms = []
let lastData = []
/** Cuánto ocupa cada campo detectado, para notar un relleno que no avisa (ver abajo). */
let huella = ''
// Los módulos YA resueltos: `submit` y `pagehide` no admiten esperar a un `import()`.
const cache = {}
mods.then((m) => Object.assign(cache, m))

function ask (op, payload) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ op, payload }, r => {
      // `no-worker` y no `unreachable`: lo que no contestó es la EXTENSIÓN, no la bóveda.
      // Con el mismo código, la pantalla decía «no estás enlazado a ninguna bóveda» a quien
      // tenía la suya delante.
      if (chrome.runtime.lastError) resolve({ error: { code: 'no-worker' } })
      else resolve(r || { error: { code: 'empty' } })
    })
  })
}

/**
 * LO PÚBLICO de lo que hay guardado para este sitio. Se pregunta una vez por página.
 *
 * `find` no abre nada: devuelve la mitad pública (§4.0.2) —qué entradas hay, con qué
 * usuario y qué guardan—, sin llave y sin aprobación. Hace falta para saber si el campo
 * merece un marcador, y es lo único que se pide sin que el usuario haya pulsado nada.
 */
let vaultFor = { host: null, entries: [], error: null }

async function entriesForHost () {
  if (vaultFor.host === location.host && !vaultFor.error) return vaultFor
  const r = await ask('find', { url: location.href })
  // UN ERROR NO SE RECUERDA. Se recordaba hasta recargar: si la bóveda no contestó una vez
  // —la pestaña de bóveda estaba cerrada, o faltaba convertirla—, la página seguía diciendo
  // que no aunque ya estuviera arreglado.
  vaultFor = { host: location.host, entries: r?.error ? [] : (r.result || []), error: r?.error?.code || null }
  return vaultFor
}

/** Lo guardado ya no vale: se acaba de escribir algo. */
function forgetEntries () {
  vaultFor = { host: null, entries: [], error: null }
}

/**
 * Los campos donde el gestor PUEDE hacer algo, que no son todos.
 *
 * Un marcador en cada casilla de cada formulario de la web es un adorno: la mitad de las
 * veces no hay nada que poner ahí. Se marca cuando hay algo guardado que quepa, o cuando
 * el campo ya tiene algo escrito y se puede ofrecer guardarlo (dueño, 2026-08-28).
 */
let shownKey = ''
// TODOS los campos detectados con lo que se puede hacer en cada uno; `lastShown` son los
// que además llevan marcador. Rellenar necesita los primeros: una contraseña vacía de un
// sitio sin nada guardado no tiene botón, y aun así hay que poder escribir en ella cuando
// el usuario trae una cuenta de otro dominio.
let lastFields = []
let lastShown = []

/**
 * UN NÚMERO POR ELEMENTO, para poder decir «este ya no es el mismo de antes».
 *
 * Va en un `WeakMap` a propósito: un campo que la página tira no deja aquí nada que lo
 * sobreviva, y en una SPA que repinta cada pocos segundos eso importa.
 */
const ids = new WeakMap()
let idSiguiente = 0
const idDe = (el) => {
  if (!ids.has(el)) ids.set(el, ++idSiguiente)
  return ids.get(el)
}

async function scan () {
  const { detect, ui } = await mods
  try {
    lastForms = detect.findLoginForms(document)
    // `free`: también los campos que no se reconocen, para poder guardar lo que el
    // usuario escriba en ellos (§4.1). Solo se marcan cuando tienen algo.
    lastData = detect.findDataFields(document, { free: true })
  } catch { lastForms = []; lastData = [] }
  // Lo que se acaba de ver ya está visto: el vigilante de rellenos solo salta si cambia.
  huella = huellaDeCampos()

  const markable = []
  for (const f of lastForms) {
    if (f.username) markable.push({ el: f.username, kind: null, form: f })
    if (f.password) markable.push({ el: f.password, kind: null, form: f })
  }
  for (const d of lastData) {
    // Un campo ya marcado como parte de un acceso no se marca dos veces.
    if (!markable.some(m => m.el === d.el)) markable.push(d)
  }

  // Sin campos no se le pregunta nada a la bóveda: una página que no tiene formularios
  // no tiene por qué despertar a nadie.
  if (!markable.length) {
    if (shownKey) { ui.mountMarkers([], onPick); shownKey = '' }
    return []
  }

  // Qué ofrecer en cada campo lo decide el service worker: comparar con lo guardado
  // necesita el valor guardado, y eso no cruza al proceso de la página. De aquí sale lo
  // escrito —que la página ya tiene— y vuelven dos booleanos y de qué entradas.
  const r = await ask('offers', {
    url: location.href,
    fields: markable.map((f, i) => descFor(f, i)),
  })
  const dicho = r?.error ? [] : (r.result || [])
  const todos = []
  const shown = []
  for (let i = 0; i < markable.length; i++) {
    const offers = dicho[i] || { fill: false, save: false, gen: false, ids: [] }
    const campo = { ...markable[i], offers, title: titleFor(offers) }
    todos.push(campo)
    if (offers.fill || offers.save || offers.gen) shown.push(campo)
  }

  // Volver a montarlos en cada tecla haría parpadear el que tienes debajo del cursor: se
  // rehacen solo cuando cambia QUÉ se marca o QUÉ ofrece.
  //
  // La clave va por ELEMENTO, no por posición, y ahí estaba un fallo que solo se ve en las
  // páginas que se repintan enteras. `<dotrino-profile>` rehace su Shadow DOM en cada
  // respuesta que recibe, así que los `input` que teníamos referenciados quedan
  // DESCONECTADOS: medirlos devuelve ceros y el marcador se esconde. Con la clave por
  // índice salía la misma de antes, así que en vez de rehacerlos solo se recolocaban —
  // contra nodos muertos, y ya no volvían (dueño, 2026-09-11: «los marcadores aparecen
  // luego desaparecen»). Con la identidad del elemento dentro, un repintado cambia la clave
  // y se rehacen, que es lo que había que hacer.
  const key = shown
    .map(f => `${idDe(f.el)}:${f.offers.fill ? 'f' : ''}${f.offers.save ? 's' : ''}${f.offers.gen ? 'g' : ''}`)
    .join('|')
  lastFields = todos
  lastShown = shown
  if (key !== shownKey) {
    ui.mountMarkers(shown, onPick)
    shownKey = key
  } else {
    ui.reposition()
  }
  autoFill().catch(() => {})
  return shown
}

/**
 * RELLENAR AL ABRIR, si el usuario lo encendió para este sitio (apagado por defecto). Quién, cuándo y
 * con qué entrada lo decide el service worker (`autofillFor`); aquí solo se pregunta una
 * vez por dirección y paso, y solo con la casilla vacía: lo que el usuario borró no se
 * repone. El paso cuenta porque un acceso en dos pasos (primero el usuario, luego la
 * contraseña) suele cambiar el formulario sin cambiar la dirección.
 */
const autoFilled = new Set()
async function autoFill () {
  if (window !== window.top) return
  const conClave = lastForms.find(x => x.password && !x.password.value)
  const soloUsuario = !conClave && lastForms.find(x => !x.password && x.username && !x.username.value)
  if (!conClave && !soloUsuario) return
  const paso = `${location.href}|${conClave ? 'secret' : 'username'}`
  if (autoFilled.has(paso)) return
  autoFilled.add(paso)
  const r = await ask('autofill')
  if (r?.error || !r?.result?.secret) return
  const relleno = await fillLogin(r.result)
  if (relleno && r.result.submit) await autoSubmit()
  scan().catch(() => {})
}

/**
 * ENVIAR AL RELLENAR, el segundo ajuste del sitio. Solo con todas las casillas llenas, y
 * solo si el service worker dice que este formulario no se ha enviado ya
 * (`autosubmit-claim`): así un acceso fallido no se reintenta en bucle, y un formulario
 * nuevo —el segundo paso— sí se envía.
 *
 * No envía al momento: enseña una cuenta atrás de AUTOSUBMIT_DELAY_S segundos con un botón
 * para cancelar (dueño, 2026-11-11). Al llegar a cero vuelve a mirar: si el formulario ya
 * no está o alguien vació una casilla, no envía.
 */
const AUTOSUBMIT_DELAY_S = 10

async function autoSubmit () {
  const { detect, ui } = await mods
  // Dejar que la página procese lo escrito: muchas habilitan el botón al recibir `input`.
  await new Promise(r => setTimeout(r, 300))
  const f = detect.findLoginForms(document).find(x => x.password) || null
  const scope = detect.submitScope(f?.password || f?.username)
  if (!scope || !detect.scopeFilled(scope)) return
  const sig = `${location.pathname}|${detect.scopeSignature(scope)}`
  // Se reclama ANTES de contar: cancelar también cuenta como «este formulario ya se vio».
  const r = await ask('autosubmit-claim', { sig })
  if (r?.error || r?.result !== true) return
  const go = await ui.showCountdown({
    seconds: AUTOSUBMIT_DELAY_S,
    label: () => t('autosubmitIn'),
    cancelLabel: t('cancel'),
  })
  if (!go || !scope.isConnected || !detect.scopeFilled(scope)) return
  detect.submitScopeNow(scope)
}

// Rellenar manda cuando hay algo guardado que poner: generar sigue estando dentro, pero
// no es lo que se viene a hacer si ya tienes la contraseña de este sitio.
const titleFor = (offers) =>
  offers.fill ? t('fill') : offers.gen ? t('suggestPassword') : t('saveThis')

/** Lo que se le cuenta al service worker de un campo para que decida. */
function descFor (f, i) {
  const { detect } = cache
  if (f.kind || f.free) {
    return {
      id: i,
      key: detect.fieldKey({ kind: f.kind, label: f.label }),
      value: String(f.el.value || '').trim(),
    }
  }
  // Un acceso: cada casilla responde por sí sola, pero se manda el formulario entero
  // porque «ya está guardado igual» se decide con la credencial completa.
  return {
    id: i,
    key: keyOf(f),
    value: String(f.el.value || '').trim(),
    username: f.form?.username?.value || '',
    secret: f.form?.password?.value || '',
  }
}

/**
 * El usuario pulsó el botón de un campo. Se abre el modal, pegado a él.
 *
 * El modal es un **iframe de la extensión** (§4.1): dentro se elige la entrada, se
 * rellena y se guarda, y ese último botón tiene que nacer fuera de la página. Aquí solo
 * se apunta antes lo que hay escrito —para que el modal tenga qué guardar— y se le
 * cuenta qué campos hay delante.
 */
async function onPick (field) {
  const { ui } = await mods

  // EL MISMO BOTÓN CIERRA. Pulsar fuera ya cierra el modal, pero el marcador vive en NUESTRO
  // anfitrión, y ese no cuenta como «fuera» —si contara, pulsar dentro del modal lo cerraría—.
  // Así que el clic llegaba aquí y lo volvía a montar: se veía cerrar y abrirse otra vez.
  // Sobre otro campo sí cambia de campo, que es lo que se espera de un menú.
  if (ui.fieldModalOpen?.() && abierto?.field?.el === field.el) {
    ui.closeFieldModal()
    abierto = null
    return
  }

  const { error } = await entriesForHost()
  if (error) {
    // Falta convertir: el mensaje dice qué pasa y el botón lleva a donde se arregla. Sin él,
    // «no se pudo hablar con tu bóveda» no dejaba ningún camino.
    const actions = error === 'not-sealed'
      ? [{ label: t('openConvert'), testid: 'open-convert', onAction: () => ask('open-convert') }]
      : []
    return ui.showModal({ title: 'Dotrino', empty: messageFor(error), actions, closeLabel: t('close') })
  }
  // Apuntar no es guardar: queda en la memoria de sesión del service worker y solo entra
  // en la bóveda si se pulsa «Guardar», que se pulsa dentro del marco.
  const puedeGuardar = field.offers?.save ? !!(await captureField(field)) : false
  abierto = { field, puedeGuardar }
  ui.mountFieldModal({
    key: keyOf(field),
    name: nameOf(field),
    anchor: field.node,
    el: field.el,
  })
}

/** El campo que tiene el modal abierto, para saber a quién contestarle. */
let abierto = null

/**
 * La CLAVE de un campo, la misma con la que viaja en el aviso y en la bóveda.
 *
 * El usuario y la contraseña de un acceso son **dos claves distintas** (`username` y
 * `secret`), no una sola: el dueño quiere verlas por separado en la lista de rellenar
 * —«Usuario» y «Contraseña»—, y juntarlas hacía que la contraseña no apareciera por
 * ninguna parte aunque se rellenara.
 */
const keyOf = (f) => {
  if (f.kind || f.free) {
    return cache.detect ? cache.detect.fieldKey({ kind: f.kind, label: f.label }) : 'other'
  }
  return f.el === f.form?.password ? 'secret' : 'username'
}

/**
 * El nombre del campo, que es **la etiqueta con la que se va a guardar**.
 *
 * Nada de «este campo»: lo que el modal enseña tiene que ser exactamente lo que quedará
 * escrito en la entrada, o el usuario está aceptando una cosa distinta de la que ve.
 */
function nameOf (field) {
  const kl = (k) => cache.i18n ? cache.i18n.kindLabel(lang, k) : k
  // Un acceso son dos campos con su nombre cada uno: «Usuario» y «Contraseña».
  if (!field.kind && !field.free) return kl(keyOf(field))
  if (field.kind) return kl(field.kind)
  // Un campo libre sin etiqueta ninguna se guarda como «otro dato», y eso es lo que dice.
  return field.label || kl('other')
}

/**
 * GUARDAR lo que hay escrito, sin esperar a enviar el formulario.
 *
 * Es el mismo camino que el aviso de después de entrar (§4.0.1): se apunta lo escrito y
 * se abre el aviso, con su lista de campos y su elección de dónde va. Lo que cambia es
 * solo el disparador — aquí lo pulsa el usuario en el campo, en vez de salir solo en la
 * página siguiente—, y quien escribe en la bóveda sigue siendo el iframe de la
 * extensión, nunca la página.
 */
async function captureField (field) {
  const { detect } = await mods

  // Se guarda ESE campo: es el que se pulsó. Los demás del mismo formulario van también,
  // pero SIN marcar — así una pulsación guarda una cosa, y si querías más están ahí sin
  // volver a empezar.
  let payload = null
  if (!field.kind && !field.free) {
    // Un acceso. Se manda lo que haya en el formulario —usuario, contraseña o las dos—,
    // y viene marcado lo del campo que se pulsó: con el usuario escrito y la contraseña
    // todavía no, guardar el usuario es una cosa razonable de querer, y la contraseña se
    // suma después a esa misma entrada.
    const f = field.form
    const username = detect.readUsername(f)
    const secret = f?.password?.value || ''
    if (!username && !secret) return false
    const esPass = field.el === f?.password
    payload = {
      from: 'field',
      username,
      secret,
      fields: detect.readDataFields(f?.form || document, { skip: [f?.username, f?.password] }),
      // La contraseña sin usuario no sirve para volver a entrar: al pulsar en ella van
      // las dos. Al pulsar en el usuario, solo él.
      focus: esPass ? ['username', 'secret'] : ['username'],
      url: location.href,
    }
  } else {
    // UN CAMPO SUELTO QUE VIVE EN UN ACCESO SIGUE SIENDO PARTE DE ESE ACCESO.
    //
    // El formulario de AWS tiene tres casillas: el ID de cuenta, el usuario y la contraseña.
    // El ID de cuenta es un campo libre, y pulsando SU marcador se mandaba `secret: ''` a
    // pelo: guardabas la cuenta de AWS sin la contraseña y sin que nada lo dijera (dueño,
    // 2026-09-11: «al abrir el marcador de Account ID or alias, no sale para almacenar el
    // password»).
    //
    // Desde el marcador del usuario la contraseña SÍ viajaba —sin marcar, para sumarla de un
    // clic—, así que dos botones del mismo formulario ofrecían cosas distintas. Ahora los dos
    // llevan la credencial de su formulario; lo único que cambia es qué viene marcado, que es
    // lo que se pulsó.
    const scope = field.el.form || document
    const acceso = lastForms.find((f) => f.form && f.form === field.el.form) || null
    const fields = detect.readDataFields(scope, { skip: [acceso?.username, acceso?.password] })
    const key = detect.fieldKey({ kind: field.kind, label: field.label })
    if (!fields.some(x => detect.fieldKey(x) === key)) return false
    payload = {
      from: 'field',
      username: acceso ? detect.readUsername(acceso) : '',
      secret: acceso?.password?.value || '',
      fields,
      focus: [key],
      url: location.href,
    }
  }

  const r = await capture(payload)
  return !r?.error
}

/**
 * RELLENAR lo que el modal pidió. Los valores vienen de la bóveda, por dentro del marco;
 * aquí solo se escriben en los campos, que es lo único que el marco no puede hacer.
 */
async function fillFromModal (values) {
  const { detect, ui } = await mods
  let generada = null
  for (const v of Array.isArray(values) ? values : []) {
    for (const f of lastFields) {
      if (keyOf(f) !== v.key) continue
      if (!v.value) continue
      detect.fillField(f.el, v.value)
      // «Repite la contraseña»: la misma, en la casilla de al lado. Dejarla vacía obliga
      // a copiarla a mano, y una contraseña generada no se copia a mano.
      if (v.key === 'secret' && f.form?.confirm) detect.fillField(f.form.confirm, v.value)
      if (v.gen) generada = f
    }
  }

  // UNA CONTRASEÑA GENERADA QUE NO SE GUARDA DEJA AL USUARIO FUERA DE SU CUENTA, y eso es
  // peor que no haberla generado. Así que se apunta en el acto: apuntar no es guardar
  // —sigue en la memoria del service worker hasta que el usuario lo diga (§4.0)—, pero a
  // partir de aquí el aviso de después de enviar ya tiene qué ofrecer, y el marcador del
  // propio campo pasa a decir «guardar» sin esperar a nada.
  if (generada) await captureField(generada)

  ui.reposition()
  // Lo escrito cambia lo que se puede ofrecer: el marcador del campo recién rellenado
  // desaparece solo (§4.1, la fila del «ya está guardado igual»).
  scan().catch(() => {})
}

/** Qué campos hay delante y qué entrada puede rellenar cada uno. Es cosmético. */
async function sendModalContext () {
  const { ui } = await mods
  const w = ui.fieldModalWindow()
  if (!w) return
  const vistos = new Set()
  const page = []
  for (const f of lastFields) {
    const k = keyOf(f)
    if (vistos.has(k)) continue
    vistos.add(k)
    page.push({ key: k, name: nameOf(f), ids: f.offers?.ids || [] })
  }
  try {
    w.postMessage({
      _dotrino: 'field-modal-context',
      page,
      canSave: !!abierto?.puedeGuardar,
      // Si el campo que se pulsó es una contraseña vacía, el modal ofrece generar una
      // (§4.1.1). Lo decide el campo, no la entrada elegida: una contraseña nueva no sale
      // de la bóveda, así que no depende de qué haya guardado.
      gen: !!abierto?.field?.offers?.gen,
      url: location.href,
    }, EXT_ORIGIN)
  } catch (_) {}
}

/**
 * El texto de un error: la misma tabla que las pantallas de la extensión (`errorText`).
 * Lo que no tiene texto propio es «no se pudo hablar con tu bóveda» — aquí no se enseña el
 * mensaje interno, que es para quien depura y la página no es sitio para eso.
 */
function messageFor (code) {
  const txt = cache.i18n.errorText(lang, { code })
  return txt === code ? t('noTalk') : txt
}

// --- lo que puede pedir el POPUP -------------------------------------------
//
// El popup es UI de la extensión, con el usuario delante; la página no. Por eso estas
// dos operaciones existen aquí y nada de esto lo puede disparar el sitio.

/** Rellena el primer formulario de acceso con una credencial que el usuario eligió. */
async function fillLogin ({ username, secret }) {
  const { detect, ui } = await mods
  if (!lastForms.length) await scan()
  const f = lastForms.find(x => x.password) || lastForms[0]
  if (!f) return false
  let done = false
  if (f.username && username) done = detect.fillField(f.username, username) || done
  if (f.password && secret) done = detect.fillField(f.password, secret) || done
  ui.reposition()
  return done
}

// --- guardar lo que acabas de escribir --------------------------------------
//
// Los gestores que la gente ya usa preguntan DESPUÉS de entrar, en la página siguiente,
// y tienen razón: al enviar el formulario ya no hay nada que leer, y pedirlo antes es
// pedirle al usuario que se acuerde. Así que se captura al enviar y se pregunta luego.
//
// **Capturar no es guardar.** Lo escrito va al service worker y se queda ahí, en la
// memoria de la sesión y con fecha de caducidad; en la bóveda no entra nada hasta que
// el usuario lo diga, y ese «sí» se pulsa en un iframe de la EXTENSIÓN, no en la
// página. La regla de siempre sigue en pie: el sitio no puede escribir en tu bóveda.

function capture (cred) {
  if (!cred) return Promise.resolve()
  // Devuelve promesa para quien pueda esperarla (el botón del campo); en `pagehide` no
  // hay tiempo de esperar nada, pero el mensaje sale igual — se despacha al llamar.
  try { return ask('capture', cred) } catch (_) { return Promise.resolve() }
}

/**
 * ¿Vale la pena preguntar por un formulario SIN contraseña?
 *
 * Un formulario de datos —el perfil, la dirección de envío, el alta de una cuenta— es
 * tan guardable como un acceso, y por eso se captura también. Pero un solo campo
 * reconocido no basta: la caja de «suscríbete a nuestro boletín» al pie de un blog es
 * exactamente eso, y preguntar ahí convierte el aviso en algo que se cierra sin leer.
 * Con dos clases distintas ya es un formulario que habla del usuario.
 *
 * Cuentan solo los RECONOCIDOS. Los campos libres viajan en la captura pero no la
 * provocan: si contaran, cualquier formulario de dos casillas sacaría el aviso.
 */
const enoughData = (fields) => fields.filter(f => f.kind).length >= 2

/**
 * Lo mismo pero sin esperar a nadie: en `pagehide` no hay tiempo para un `await`.
 * Con `force` se salta el mínimo de dos datos: es para cuando el usuario lo pide.
 *
 * `from` dice CÓMO se capturó, y no es cosmético: `submit` es el usuario enviando el
 * formulario —así que lo que cargue después en esta pestaña es a donde ese acceso le
 * llevó—, y `leave` es solo irse de la página. El aviso lo usa para decidir dónde puede
 * salir (ver `pendingSave` en el service worker).
 */
function captureFrom (form, { force = false, from = 'submit' } = {}) {
  const { detect } = cache
  if (!detect) return false
  const secret = form?.password?.value || ''
  // El ámbito es el formulario enviado, no la página: en una pantalla con dos
  // formularios, lo que se guarda es lo del que se envió.
  const scope = form?.form || document
  const fields = detect.readDataFields(scope, { skip: [form?.username, form?.password] })
  if (!secret && !(force ? fields.length : enoughData(fields))) return false
  return capture({
    from,
    username: secret ? detect.readUsername(form) : '',
    secret,
    fields,
    // Marcado viene lo que el gestor reconoce; los campos libres van sin marcar. Enviar
    // un formulario no es pedir que se guarde el código de un cupón, pero tenerlo ahí
    // a un clic sí ahorra volver a escribirlo.
    focus: ['username', 'secret', ...fields.filter(f => f.kind).map(f => detect.fieldKey(f))],
    url: location.href,
  })
}

// El usuario ESCRIBIÓ algo. Se apunta porque `pagehide` no sabe distinguir entre salir
// de un formulario que acabas de llenar y salir de una página que solo lo enseñaba: sin
// esto, abrir tus ajustes y volver atrás pediría guardar lo que ya estaba ahí.
let touched = false
let typingT = null
const onTyped = () => {
  touched = true
  // Escribir cambia lo que el gestor puede ofrecer: un campo vacío no tiene nada que
  // guardar, y en cuanto tiene algo, sí. Con freno, que esto corre por cada tecla.
  clearTimeout(typingT)
  typingT = setTimeout(() => { scan().catch(() => {}) }, 250)
}
addEventListener('input', onTyped, { capture: true, passive: true })
// `change` también: hay gestores que rellenan disparando solo ese.
addEventListener('change', onTyped, { capture: true, passive: true })

/**
 * LO QUE RELLENA OTRO SIN AVISAR (dueño, 2026-09-28: «no detecta los fields autollenados
 * por otras extensiones o el password manager de Chrome»).
 *
 * Quien rellena desde fuera escribe `value` y no siempre dispara ningún evento. Y Chrome,
 * al autocompletar una contraseña, no deja leerla a la página hasta el primer clic — y
 * cuando la deja, tampoco avisa. Así que se mira: una vez por segundo, con la pestaña a la
 * vista, cuánto ocupa cada campo ya detectado. Si cambió, se vuelve a pasar.
 *
 * Se guarda la LONGITUD, no el valor: esto no tiene por qué tener la contraseña en memoria.
 * No marca `touched`: nadie tecleó, y rellenar solo no es llenar un formulario.
 */
const huellaDeCampos = () => {
  const els = []
  for (const f of lastForms) els.push(f.username, f.password)
  for (const d of lastData) els.push(d.el)
  return els.filter(Boolean).map(el => String(el.value || '').length).join(',')
}
setInterval(() => {
  if (document.hidden || !(lastForms.length || lastData.length)) return
  const h = huellaDeCampos()
  if (h === huella) return
  huella = h
  scan().catch(() => {})
}, 1000)

// 1. El envío del formulario, que es el caso normal. En captura para que llegue aunque
//    la página cancele el evento después.
addEventListener('submit', (e) => {
  const el = e.target
  const f = lastForms.find(x => x.form && x.form === el)
  if (f && captureFrom(f)) return
  // Sin nada detectado todavía (una SPA que acaba de montar el formulario): se mira el
  // propio formulario que se envía, que es síncrono y no depende de la última pasada.
  const pass = el?.querySelector?.('input[type=password]')
  if (pass?.value && captureFrom({ form: el, password: pass, username: null })) return
  // Y sin contraseña ninguna: un formulario de datos. El freno está en `captureFrom`.
  if (captureFrom({ form: el, password: null, username: null })) return
  for (const x of lastForms) if (captureFrom(x)) return
}, true)

/**
 * ENVIAR SIN `submit`: un botón que llama a `fetch` y navega a mano, que es media web.
 *
 * Para el aviso eso es un envío igual —el usuario pulsó «Entrar»—, y la diferencia
 * importa: solo un envío deja que lo apuntado siga a la pestaña cuando el acceso te
 * deja en otro host (ver `pendingSave` en el service worker). Así que se apunta cuándo
 * se pulsó un botón de la página.
 *
 * Un ENLACE no cuenta, y es la mitad de la regla: irse por un enlace, por la barra de
 * direcciones o por el botón de atrás es irse, no entrar — y lo que quedó escrito no
 * tiene por qué asomarse en el sitio siguiente.
 */
let pulsado = 0
const PULSADO_MS = 5000
addEventListener('click', (e) => {
  if (e.target?.closest?.('button, input[type=submit], input[type=button], input[type=image]')) {
    pulsado = Date.now()
  }
}, { capture: true, passive: true })

// 2. Y la salida de la página, porque media web entra sin disparar `submit`: un botón
//    que llama a `fetch` y navega a mano. Sin esto el gestor solo aprendería de los
//    formularios de siempre, que son cada vez menos.
addEventListener('pagehide', () => {
  // Si acaba de pulsar un botón, esto es un envío aunque no haya `submit`.
  const from = Date.now() - pulsado < PULSADO_MS ? 'submit' : 'leave'
  for (const f of lastForms) if (captureFrom(f, { from })) return
  // Un formulario de datos no aparece en `lastForms` (ahí solo van los accesos), así que
  // se mira la página entera — pero solo si el usuario escribió: ver una pantalla no es
  // llenarla.
  if (touched) captureFrom({ form: null, password: null, username: null }, { from })
}, { capture: true })

/**
 * ¿Quedó algo por preguntar de la página anterior? Se pregunta aquí, ya cargada.
 *
 * Y se pregunta VARIAS VECES durante unos segundos, no una sola: entre enviar el
 * formulario y cargar la página siguiente hay una carrera de verdad —el service worker
 * puede estar dormido y tardar en anotar lo capturado, y la página nueva suele llegar
 * antes—. Preguntando una vez el aviso no salía casi nunca; costó verlo porque no falla,
 * simplemente no aparece.
 */
async function offerSave (waits = [0, 400, 1000, 2000]) {
  for (const wait of waits) {
    if (wait) await new Promise(r => setTimeout(r, wait))
    const r = await ask('pending-save', { host: location.hostname })
    const p = r?.result
    if (!p?.has) continue
    // Un sí y nada más: ni el sitio ni el usuario pasan por aquí. Todo lo que el aviso
    // enseña se lo pregunta él al service worker desde el origen de la extensión.
    //
    // Dentro de un marco no se dibuja nada: el service worker ya avisó a la página
    // principal, que es la única que monta el aviso.
    if (EN_MARCO) return
    await showSavePrompt(p.ts)
    return
  }
}

// ¿Este script corre dentro de un marco? El aviso de guardar es de la página principal.
const EN_MARCO = window !== window.top

// La captura que ya se enseñó. Una página y un marco suyo del mismo sitio preguntan los
// dos, y sin esto el aviso se montaría dos veces seguidas.
let avisoDe = null
async function showSavePrompt (ts) {
  const { ui } = await mods
  if (ts === avisoDe && ui.promptWindow()) return
  avisoDe = ts
  ui.mountSavePrompt()
}

// El aviso se cierra y se dimensiona solo: es un iframe de la extensión y no alcanza al
// DOM de aquí, así que lo pide por `postMessage`.
//
// Y se comprueba de DÓNDE viene: en esta ventana cualquiera puede hacer `postMessage`, y
// sin el filtro la página podría cerrar el aviso —o estirarlo hasta taparlo todo— con
// una línea. Vale el origen de la extensión o la ventana del propio iframe.
const EXT_ORIGIN = new URL(chrome.runtime.getURL('')).origin
const DE_LOS_MARCOS = new Set([
  'close-save-prompt', 'size-save-prompt',
  'field-modal-ready', 'close-field-modal', 'size-field-modal',
  'fill-field-modal', 'saved-field-modal',
])

addEventListener('message', async (e) => {
  const op = e.data?._dotrino
  if (!DE_LOS_MARCOS.has(op)) return
  const { ui } = await mods
  // De DÓNDE viene: en esta ventana cualquiera puede hacer `postMessage`, y sin el filtro
  // la página podría cerrar el aviso, estirarlo hasta taparlo todo o mandar a rellenar.
  const suyo = e.source === ui.promptWindow() || e.source === ui.fieldModalWindow()
  if (e.origin !== EXT_ORIGIN && !suyo) return

  switch (op) {
    case 'close-save-prompt':
      ui.closeSavePrompt()
      // Puede que se acabe de guardar algo: lo que se sabía de la bóveda ya no vale, y
      // los marcadores de la página tienen que enterarse.
      forgetEntries()
      scan().catch(() => {})
      break
    case 'size-save-prompt': ui.sizeSavePrompt(e.data.h); break
    case 'field-modal-ready': sendModalContext(); break
    case 'close-field-modal':
      ui.closeFieldModal(); abierto = null
      // Desde el modal se puede cambiar de cuenta: lo que se sabía era de la otra bóveda.
      forgetEntries()
      scan().catch(() => {})
      break
    case 'size-field-modal': ui.sizeFieldModal(e.data.h); break
    case 'fill-field-modal': fillFromModal(e.data.values); break
    case 'saved-field-modal': forgetEntries(); scan().catch(() => {}); break
  }
})

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Solo del propio popup: un messageFor con `sender.tab` viene de una página.
  if (sender.tab) { sendResponse({ error: { code: 'denied' } }); return false }

  // Un marco de esta página tiene algo que ofrecer guardar: lo dibuja la página principal.
  if (msg?.op === 'offer-save') {
    if (EN_MARCO) { sendResponse({ error: { code: 'not-top-frame' } }); return false }
    showSavePrompt(msg.payload?.ts).then(() => sendResponse({ result: { ok: true } }))
    return true
  }

  if (msg?.op === 'page-fill') {
    fillLogin(msg.payload || {}).then(filled => sendResponse({ result: { filled } }))
    return true
  }
  return false
})

// El modal se cierra al pulsar fuera, como cualquier menú: es de un campo, y en cuanto
// tocas otra cosa ya no habla de lo que estás mirando. Pulsar DENTRO no llega hasta aquí
// —es un iframe, y sus clics se quedan en él—, así que basta con mirar los de la página.
addEventListener('mousedown', async (e) => {
  const { ui } = cache
  if (!ui?.fieldModalOpen?.()) return
  // El anfitrión de nuestra UI no es «fuera»: ahí viven el marcador y el propio modal.
  if (e.target?.id === ui.HOST_ID) return
  ui.closeFieldModal()
  abierto = null
}, true)

// Y con Escape, que es lo que hace todo el mundo antes de buscar el botón de cerrar.
addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return
  const { ui } = cache
  if (!ui?.fieldModalOpen?.()) return
  ui.closeFieldModal()
  abierto = null
}, true)

// Las SPA remontan el formulario después de cargar; sin esto el gestor funciona en la
// primera visita y deja de funcionar al navegar dentro del sitio.
let scanT = null
const observer = new MutationObserver(() => {
  clearTimeout(scanT)
  scanT = setTimeout(() => { scan().catch(() => {}) }, 300)
})
observer.observe(document.documentElement, { childList: true, subtree: true })

// Los botones van pegados a sus campos: si la página se mueve, ellos también.
let raf = null
const seguir = () => {
  if (raf) return
  raf = requestAnimationFrame(async () => { raf = null; (await mods).ui.reposition() })
}
addEventListener('scroll', seguir, { passive: true, capture: true })
addEventListener('resize', seguir, { passive: true })

scan().catch(() => {})
offerSave().catch(() => {})
