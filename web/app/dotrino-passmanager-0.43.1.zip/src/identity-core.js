// La identidad del ecosistema DENTRO del service worker.
//
// El multi-perfil de Dotrino ya está escrito y probado en `@dotrino/identity`; lo que no
// entra aquí es la clase `Identity`, que habla con `id.dotrino.com` montando un iframe —
// y un service worker MV3 no tiene DOM. Lo reutilizable es el núcleo:
// `createIdentityCore({ kv, peers, keyStore })` no toca DOM, y con él cada perfil tiene
// su llave de verdad (acta, delegaciones, certificados) en vez de una inventada aquí.
//
// Este archivo es solo el adaptador: le da al núcleo las tres piezas que pide, hechas
// con lo que un worker sí tiene.

import { createIdentityCore } from './vendor/identity/core.js'
import { avatarDataUri } from './vendor/identity/avatar.js'

/**
 * El núcleo quiere un `kv` SÍNCRONO estilo `localStorage`, y `chrome.storage.local` es
 * asíncrono. Se hidrata entero en memoria al arrancar y se escribe detrás.
 *
 * Se puede porque lo que guarda son claves de identidad y listas cortas, no la bóveda:
 * las contraseñas nunca pasan por aquí. Y el arranque es el único punto donde esperar,
 * que es exactamente lo que un worker que se duerme necesita — al despertar, rehidrata.
 */
async function hydratedKv (prefix = 'identity/') {
  const all = await chrome.storage.local.get(null)
  const mem = new Map()
  for (const [k, v] of Object.entries(all)) {
    if (k.startsWith(prefix)) mem.set(k.slice(prefix.length), v)
  }
  let pending = Promise.resolve()
  const flush = (k, v) => {
    pending = pending.then(() => (v === undefined
      ? chrome.storage.local.remove(prefix + k)
      : chrome.storage.local.set({ [prefix + k]: v })))
    // Un fallo al escribir la identidad no se traga: sin esto, la llave se regenera y
    // toda bóveda que conocía este aparato deja de reconocerlo, días después y sin
    // ninguna pista de por qué.
    pending.catch(e => console.error('[identity] no se pudo guardar «%s»: %s', k, e?.message || e))
  }
  return {
    getItem: (k) => (mem.has(k) ? mem.get(k) : null),
    setItem: (k, v) => { mem.set(k, String(v)); flush(k, String(v)) },
    removeItem: (k) => { mem.delete(k); flush(k, undefined) },
    /** Para cuando el worker despierta y la memoria se fue con él. */
    async rehydrate () {
      const fresh = await chrome.storage.local.get(null)
      mem.clear()
      for (const [k, v] of Object.entries(fresh)) if (k.startsWith(prefix)) mem.set(k.slice(prefix.length), v)
    },
    get flushed () { return pending },
  }
}

/**
 * EL KV DE SESIÓN, que es lo que hace posible una CUENTA DE PASO aquí.
 *
 * En una pestaña, una cuenta de paso la reclama `sessionStorage` y muere con la pestaña.
 * Un service worker no tiene pestaña ni `sessionStorage` — y, peor, **se duerme a los 30 s
 * y pierde la memoria**, así que tenerla solo en RAM dejaba al usuario fuera sin tocar
 * nada. `chrome.storage.session` es el equivalente exacto: vive en memoria, NO se escribe
 * en el disco y se vacía al cerrar el navegador. Y como el núcleo nunca barre la cuenta
 * RECLAMADA, sobrevive a que el worker se duerma y despierte.
 *
 * Que esto no exista no es un detalle: sin él, la cuenta se barre al despertar y la llave
 * se borra. Por eso aquí se espera a hidratarlo, como el otro.
 */
async function hydratedSessionKv (prefix = 'identity.session/') {
  const all = await chrome.storage.session.get(null)
  const mem = new Map()
  for (const [k, v] of Object.entries(all)) {
    if (k.startsWith(prefix)) mem.set(k.slice(prefix.length), v)
  }
  let pending = Promise.resolve()
  const flush = (k, v) => {
    pending = pending.then(() => (v === undefined
      ? chrome.storage.session.remove(prefix + k)
      : chrome.storage.session.set({ [prefix + k]: v })))
    pending.catch(e => console.error('[identity] no se pudo guardar la sesión «%s»: %s', k, e?.message || e))
  }
  return {
    getItem: (k) => (mem.has(k) ? mem.get(k) : null),
    setItem: (k, v) => { mem.set(k, String(v)); flush(k, String(v)) },
    removeItem: (k) => { mem.delete(k); flush(k, undefined) },
    get flushed () { return pending },
  }
}

/** Las CryptoKeys no extraíbles: IndexedDB las clona sin exportarlas. */
function makeKeyStore (dbName = 'dotrino-identity-keys') {
  const idb = (mode, fn) => new Promise((resolve, reject) => {
    const open = indexedDB.open(dbName, 1)
    open.onupgradeneeded = () => {
      if (!open.result.objectStoreNames.contains('keys')) open.result.createObjectStore('keys')
    }
    open.onerror = () => reject(open.error)
    open.onsuccess = () => {
      const db = open.result
      const tx = db.transaction('keys', mode)
      const req = fn(tx.objectStore('keys'))
      req.onsuccess = () => { resolve(req.result); db.close() }
      req.onerror = () => { reject(req.error); db.close() }
    }
  })
  return {
    get: (k) => idb('readonly', s => s.get(k)),
    set: (k, v) => idb('readwrite', s => s.put(v, k)),
    remove: (k) => idb('readwrite', s => s.delete(k)),
  }
}

/**
 * Los contactos. El núcleo los pide siempre, aunque el gestor de contraseñas no tenga
 * ninguno: aquí viven en el mismo kv y ya está.
 */
function makePeers (kv) {
  const KEY = 'dotrino.identity.peers'
  let dirty = () => {}
  const load = () => { try { return JSON.parse(kv.getItem(KEY) || '{}') || {} } catch { return {} } }
  const save = (m) => { kv.setItem(KEY, JSON.stringify(m)); dirty() }
  return {
    async initPeerStorage () {},
    loadPeers: load,
    savePeers: save,
    setPeersDirect: (m) => { kv.setItem(KEY, JSON.stringify(m || {})) },
    upsertPeer: (publickey, patch) => {
      const m = load()
      m[publickey] = { ...(m[publickey] || {}), ...patch, publickey }
      save(m)
      return m[publickey]
    },
    onDirty: (fn) => { dirty = fn || (() => {}) },
  }
}

let core = null
let kv = null
let sessionKv = null
let booting = null

/** El núcleo de identidad de esta extensión, uno solo, con el perfil activo abierto. */
export async function identityCore () {
  if (core) return core
  // Una sola arrancada aunque lleguen tres peticiones a la vez: dos núcleos sobre el
  // mismo almacén se pisarían las llaves.
  booting ||= (async () => {
    kv = await hydratedKv()
    sessionKv = await hydratedSessionKv()
    core = await createIdentityCore({
      kv,
      sessionKv,
      peers: makePeers(kv),
      keyStore: makeKeyStore(),
      // Sin sincronización con Drive: el gestor no la usa y arrastraría DOM.
      makeSync: null,
    })
    return core
  })()
  return booting
}

/**
 * Cambiar de perfil obliga a REARRANCAR el núcleo.
 *
 * En una app del ecosistema eso lo hace recargar la página — el multi-perfil no es
 * reactivo por diseño. Aquí no hay página que recargar, así que se tira el núcleo y se
 * levanta otro: es la misma decisión, cumplida donde no hay recarga.
 */
async function restart () {
  // Antes de rehacerlo hay que esperar a que lo escrito EXISTA en el disco: el kv vive en
  // memoria y vuelca detrás, así que un núcleo nuevo leería el estado de antes y el perfil
  // recién creado se esfumaría. Costó una vuelta encontrarlo.
  await kv?.flushed
  core = null
  booting = null
  return identityCore()
}

/** La identidad del ecosistema, en lo que el gestor necesita de ella. */
export const identity = {
  async profiles () {
    const { handlers } = await identityCore()
    const list = await handlers.listProfiles()
    // Cada perfil nace con imagen: el identicon se deriva de su pública, así que no hay
    // que pedirle nada al usuario ni dejar un hueco gris hasta que suba una foto.
    return list.map(p => ({ ...p, avatar: p.avatar || (p.pubkey ? avatarDataUri(p.pubkey, { size: 40 }) : null) }))
  },
  async current () {
    const { handlers } = await identityCore()
    return handlers.currentProfile()
  },
  async create (name) {
    const { handlers } = await identityCore()
    const p = await handlers.createProfile({ name: name || '' })
    // `createProfile` lo crea y lo abre en memoria, pero no lo deja como ACTIVO: eso es
    // `switchProfile`, y sin él la extensión seguiría enseñando el perfil de antes.
    await handlers.switchProfile({ id: p.id })
    await restart()
    return p
  },
  async use (id) {
    const { handlers } = await identityCore()
    await handlers.switchProfile({ id })
    await restart()
  },
  async rename (id, name) {
    const { handlers } = await identityCore()
    return handlers.renameProfile({ id, name: name || '' })
  },
  async remove (id) {
    const { handlers } = await identityCore()
    await handlers.deleteProfile({ id })
    await restart()
  },
  // ----- ENTRAR CON USUARIO Y CONTRASEÑA (`docs/temporary-access.md`) ---------
  //
  // La CONVERSACIÓN con la bóveda no está aquí: vive en la página (`logins.js`), porque el
  // OPAQUE es WASM y en una extensión eso solo corre en la página sandbox. Aquí llega ya
  // resuelto —el aparato, su papel y su acta— y lo único que queda es la segunda mitad:
  // instalarlo como una cuenta más de este navegador.
  //
  // Es `core.adoptLogin` y no un handler a propósito: el núcleo no deja que una aplicación
  // instale una identidad. Aquí quien llama es la propia extensión.

  /**
   * Adopta lo que devolvió `loginWithPassword`. Con `remember: false` —lo normal en un
   * equipo prestado— la cuenta vive en memoria y se va al cerrar.
   */
  async adoptLogin (entrada, { remember = false, proxy = null } = {}) {
    const c = await identityCore()
    const r = await c.adoptLogin(entrada, { remember, proxy })
    // AQUÍ NO SE REARRANCA EL NÚCLEO, y es justo lo contrario de lo que parece.
    //
    // `switchProfile` sí obliga a rearrancar porque solo mueve un puntero en el kv y el
    // núcleo ya tiene otro perfil abierto. `adoptLogin` no: abre la cuenta nueva él mismo,
    // dentro. Rearrancar tiraba el núcleo con la cuenta de paso dentro —vive en su memoria
    // a propósito, no en la lista del disco— y el navegador volvía a la cuenta de antes
    // como si no hubieras entrado. Costó verlo porque no falla: entra bien y no pasa nada.
    await kv?.flushed
    await sessionKv?.flushed
    return r
  },

  /**
   * De qué inicio de sesión se trata el perfil ACTIVO, o `null` si no se entró con
   * contraseña. Lo pide la página para avisar a la bóveda antes de salir: aquí no hay
   * socket, y el aviso es lo que suelta la plaza al otro lado.
   */
  async loginMeta () {
    const { handlers } = await identityCore()
    const list = await handlers.listProfiles()
    const p = list.find((x) => x.current)
    if (!p?.login) return null
    // La lista solo trae lo que se enseña (`user`, `address`, si es de paso). Para AVISAR
    // hacen falta además el `sid` y el proxio, que están en el registro del perfil — y el
    // registro está acotado a su cuenta, de ahí el `p.<pid>.` por delante.
    let meta = null
    try { meta = JSON.parse(kv.getItem(`dotrino.identity.p.${p.id}.login`) || 'null') } catch (_) {}
    if (!meta?.sid) return null
    const c = await identityCore()
    return { ...meta, id: p.id, publickey: c.me?.publickey || null }
  },

  /** Salir: se le avisa a la bóveda y la cuenta desaparece de este navegador. */
  async leaveLogin (id = null) {
    const { handlers } = await identityCore()
    const r = await handlers.logoutLogin({ id })
    // Tampoco: salir también deja el núcleo en la cuenta a la que se vuelve.
    await kv?.flushed
    await sessionKv?.flushed
    return r
  },

  // ----- EL PERFIL: nombre, foto, redes, datos (CONVENCIONES §6.1) ------------
  //
  // Lo edita `<dotrino-profile>`, el componente del ecosistema, desde el gestor. El núcleo
  // ya guardaba este registro —y lo empuja a la bóveda para que sea el mismo en todos tus
  // aparatos—; lo que faltaba era asomarlo por aquí.

  /** El registro completo del perfil activo. */
  async getMe () {
    const { handlers } = await identityCore()
    return handlers.getMe()
  },

  /**
   * Guarda un PATCH: lo que no venga en él no se toca. Es como lo pide el núcleo, y es lo
   * que evita que editar un teléfono borre la foto.
   */
  async updateMe (patch) {
    const { handlers } = await identityCore()
    return handlers.updateMe({ patch: patch || {} })
  },

  /** La pública del perfil activo: con ella lo conoce la bóveda. */
  async publickey () {
    const c = await identityCore()
    return c.me?.publickey || null
  },
  /**
   * Firma con la llave del PERFIL, no con una llave suelta del transporte.
   *
   * Es la regla del ecosistema: la identidad de red es la misma que la de firma, así el
   * aparato que se identifica en el proxio y el que la bóveda conoce son uno solo.
   */
  async sign (data) {
    const { handlers } = await identityCore()
    return handlers.signData({ data })
  },

  // ----- sellado: la llave de CIFRADO del perfil, la que la bóveda conoce por el acta -----
  //
  // La privada no sale de aquí: se le pide que abra, no que la entregue.
  async encryptionPubkey () {
    const { handlers } = await identityCore()
    return handlers.getEncryptionPubkey()
  },
  async encrypt (recipients, plaintext) {
    const { handlers } = await identityCore()
    return handlers.encrypt({ recipients, plaintext })
  },
  /** Devuelve el texto, no `{ plaintext }`: el sobre se abre para leerlo. */
  async decrypt (senderEncryptionPubkey, envelope) {
    const { handlers } = await identityCore()
    return (await handlers.decrypt({ senderEncryptionPubkey, myToken: null, envelope })).plaintext
  },

  /**
   * ABRE UN SOBRE SELLADO A ESTE APARATO: primero la envoltura de la llave —con la privada
   * de cifrado, que no sale de este núcleo— y con ella el sobre.
   *
   * Es lo que hace falta para las contraseñas selladas: la bóveda ya no abre nada, así que
   * cada aparato abre lo suyo (`docs/sealed-passwords.md` §2.3).
   */
  async openSealed ({ wrap, envelope }) {
    const { handlers } = await identityCore()
    return handlers.openSealedValue({ wrap, envelope })
  },

  // ----- emparejamiento con la bóveda: el del ecosistema, sin nada propio -----

  /** Con qué bóveda está emparejado este perfil (`{ paired, master, proxy, … }`). */
  async vaultStatus () {
    const { handlers } = await identityCore()
    return handlers.vaultStatus()
  },

  /**
   * La llave de CIFRADO de la bóveda, para sellarle lo que se le pide. Sale del ACTA,
   * como la de cualquier miembro: no hay que pedírsela ni pegarla en ninguna parte.
   */
  async vaultEncPub () {
    const { handlers } = await identityCore()
    const v = await handlers.vaultStatus()
    if (!v?.paired) return null
    const { members } = await handlers.profileMembers()
    return (members || []).find((m) => m.pub === v.master)?.encPub || null
  },

  // ----- APROBAR pedidos de OTROS aparatos (§2.0) -----------------------------
  //
  // Un aparato con el permiso `aprueba` es el que contesta cuando otro pide una llave
  // privada a la bóveda. La app de Android y una pestaña enrolada ya lo hacían; esta
  // extensión tenía la capacidad en su identidad y nada que la usara (dueño, 2026-08-30:
  // *«el permiso de aprobador también se lo puede dar a la misma extensión»*).
  //
  // Ojo con lo que NO es: esto no tiene que ver con la puerta de la bóveda de dentro
  // (`ApprovalGate`), que es cuando la extensión ES la bóveda. Aquí la bóveda es otra y
  // esto es el aparato que le dice que sí.

  /**
   * PONERSE AL DÍA con la bóveda: traerse el acta y, con ella, los permisos.
   *
   * Es `listVaultDevices`, y no es un rodeo: **el acta viaja con esa lista**, que es el
   * canal que el pilar tiene para que los cambios de política lleguen sin inventar otro.
   * Al adoptarla, si trae permisos que el papel no lleva, el papel se renueva ahí mismo.
   *
   * Hace falta porque una extensión no es una página: el núcleo de identidad vive en el
   * service worker y, una vez abierto, se queda con el acta que recibió al enrolarse. Una
   * pestaña se pone al día sola en cada carga; esto no. Sin esto, dar un permiso nuevo a
   * la extensión no llegaba NUNCA (visto el 2026-08-30, probando que aprobara pedidos).
   *
   * Reabrir el núcleo no sirve, y se intentó: lo que se jala al abrir es el PERFIL —el
   * apodo, el avatar—, no el acta.
   */
  async refresh () {
    const { handlers } = await identityCore()
    try { await handlers.listVaultDevices() } catch (_) { /* bóveda apagada: lo de antes sigue */ }
    return { ok: true }
  },

  /** ¿Puede este navegador aprobar pedidos? Lo dice el papel que le dio la bóveda. */
  async canApprove () {
    const { handlers } = await identityCore()
    if (typeof handlers.canApproveVault !== 'function') return false
    return handlers.canApproveVault()
  },

  /** Los pedidos que esperan, o la respuesta a uno: `op` es `approvals`/`approve`/`deny`. */
  async approvals (op, id) {
    const { handlers } = await identityCore()
    return handlers.vaultApprovals({ op, ...(id ? { id } : {}) })
  },

  /**
   * Conectar este navegador a una bóveda: el enrolamiento estándar
   * (`vaultPair`) — llave nueva, código de seis que se teclea en la bóveda, cert
   * firmado por la maestra y entrada en el acta del perfil.
   *
   * `join: 'new'` porque la cuenta de la bóveda entra COMO OTRA cuenta de este
   * navegador: la que ya usabas no se toca. Y como el multi-perfil no es reactivo, se
   * deja ACTIVA la nueva y se rearranca el núcleo, igual que al crear un perfil.
   */
  async pairWithVault ({ qr, label, onCode }) {
    const c = await identityCore()
    const off = c.onVaultEvent((e) => {
      if (e?.phase === 'challenge') { try { onCode?.({ code: e.code, deviceId: e.deviceId }) } catch (_) {} }
    })
    try {
      const r = await c.handlers.vaultPair({ qr, label: label || '', join: 'new' })
      const prof = await c.handlers.currentProfile()
      await c.handlers.switchProfile({ id: prof.id })
      await restart()
      return { ...r, profileId: prof.id }
    } finally { off() }
  },
}
