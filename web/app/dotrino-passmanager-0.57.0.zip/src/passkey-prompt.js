// EL AVISO DE «¿DÓNDE GUARDO LA PASSKEY?», cuando un sitio pide crear una.
//
// Corre en el origen de la extensión (un iframe suyo incrustado en la página): el clic que
// escribe en la bóveda nace aquí, no en el sitio, y el sitio no puede pulsarlo ni fingirlo.
// Dos salidas, y ninguna en silencio: «Guardar en Dotrino», o «Ahora no», que se la deja
// al navegador como siempre (dueño, 2026-10-16).

import { t, pickLang, errorText } from './i18n.js'
import { askWorker as ask } from './page.js'

const lang = pickLang()
const $ = (id) => document.getElementById(id)
const req = decodeURIComponent(location.hash.slice(1))

document.documentElement.lang = lang
$('title').textContent = t(lang, 'pkTitle')
$('why').textContent = t(lang, 'pkWhy')
$('save').textContent = t(lang, 'pkSave')
$('no').textContent = t(lang, 'notNow')


const post = (msg) => { try { window.parent.postMessage(msg, '*') } catch (_) {} }
const close = () => post({ _dotrino: 'close-passkey-prompt' })
const resize = () => requestAnimationFrame(() =>
  post({ _dotrino: 'size-passkey-prompt', h: Math.ceil(document.documentElement.getBoundingClientRect().height) + 2 }))

function fail (e) {
  $('err').textContent = errorText(lang, e)
  $('err').hidden = false
  // «Guardando…» ya no es verdad: lo que queda es el error.
  $('why').hidden = true
  // El sitio ya siguió con el navegador: aquí solo queda cerrar.
  $('save').hidden = true
  $('no').textContent = t(lang, 'close')
  $('no').disabled = false
  $('no').onclick = close
  resize()
}

$('no').onclick = async () => {
  $('save').disabled = true; $('no').disabled = true
  try { await ask('passkey-choose', { req, choice: 'browser' }) } catch (_) {}
  close()
}

$('save').onclick = async () => {
  $('save').disabled = true; $('no').disabled = true
  $('why').textContent = t(lang, 'pkSaving')
  try {
    await ask('passkey-choose', { req, choice: 'dotrino' })
    close()
  } catch (e) { fail(e) }
}

try {
  const o = await ask('passkey-offer', { req })
  $('who').textContent = t(lang, 'pkFor', o.rpName && o.rpName !== o.rpId ? `${o.rpName} (${o.rpId})` : o.rpId, o.userName)
  if (o.mode === 'get') {
    // ENTRAR: no hay nada que elegir, solo esperar —quizá una aprobación en el teléfono— y
    // poder irse al navegador. Lo que no se hace es esperar sin decirlo.
    $('title').textContent = t(lang, 'pkGetTitle')
    $('why').textContent = t(lang, 'pkGetWhy')
    $('save').hidden = true
    $('no').textContent = t(lang, 'pkUseBrowser')
    resize()
    try { await ask('passkey-wait', { req }); close() } catch (e) { fail(e) }
  } else {
    $('save').disabled = false
    $('save').focus()
  }
} catch (e) { fail(e) }
resize()
