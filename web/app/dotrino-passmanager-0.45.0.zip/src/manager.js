// EL GESTOR DE REGISTROS: administrar lo guardado, en su propia pestaña (DISENO §4.3).
//
// Es una página de la extensión (`chrome-extension://…/src/manager.html`), no un sitio
// web, y eso es lo que le permite pedir cualquier operación: la lista recortada de
// operaciones es para las páginas ajenas. Se abre desde el popup, con `chrome.tabs.create`.
//
// **Por qué existe aparte del popup.** El popup es lo rápido del sitio que tienes
// delante: rellenar, copiar, cuál es la predeterminada. Editar un registro no tiene nada
// que ver con la página en la que estás (dueño, 2026-08-29) y no cabe en 360 px.
//
// **NO trae valores privados, ni aquí ni en ningún sitio.** Un campo privado se enseña
// tapado y se puede REEMPLAZAR escribiendo encima; para saber si lo escrito cambia algo
// se comparan resúmenes (§4.0.2), que es lo mismo que hacen el aviso y el modal del campo
// — un método de comparación, no dos.
//
// **Un botón para todo**: los cambios de la ficha entera se guardan de una vez, o se
// cancelan de una vez (dueño, 2026-08-29). Nada de guardar campo a campo.
//
// Sin `alert`/`confirm`/`prompt` (CONVENCIONES §5).

import { pickLang, t, kindLabel, fieldLabel, errorText } from './i18n.js'
import { KINDS } from './vendor/passmanager/fields.js'
import { DEVICE_CAPS } from './vendor/identity/acta.js'
import { entryCard, byName } from './entry-card.js'
// El perfil se abre desde el BOTÓN de la barra, que enseña el selector del ecosistema: esta
// pantalla es para administrar los registros (§5.1, y el gestor no es la ficha de nadie).
import { wireTopbar } from './profile-card.js'
// La bóveda puede preguntar mientras esta pestaña está delante (no por editar —que no
// saca nada—, pero sí si el usuario copia algo desde aquí más adelante): la pregunta sale
// en esta misma página, como en el resto de pantallas de la extensión.
import { hostApprovals } from './approval.js'
// ENTRAR CON USUARIO Y CONTRASEÑA. Corre EN ESTA PÁGINA y no en el service worker: el
// OPAQUE vive en una página sandbox —que un worker no puede embeber— y el socket aguanta lo
// que aguante esta pestaña, que es mucho más que los 30 s de un worker.
import * as logins from './logins.js'

hostApprovals()

let lang = pickLang()
const view = document.getElementById('view')
const toastEl = document.getElementById('toast')

// Los cuatro de siempre. No son campos libres: no se pueden borrar de la entrada, se
// vacían; y tres de ellos son privados por lo que son, no por una marca (§4.2).
const BUILTIN = ['username', 'secret', 'totp', 'notes']
const SIEMPRE_PRIVADOS = ['secret', 'totp', 'notes']

function ask (op, payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ op, payload }, r => {
      if (chrome.runtime.lastError) return reject(Object.assign(new Error(chrome.runtime.lastError.message), { code: 'no-worker' }))
      if (r?.error) return reject(Object.assign(new Error(r.error.message || r.error.code), { code: r.error.code }))
      resolve(r?.result)
    })
  })
}

let toastTimer
function toast (text, kind) {
  toastEl.textContent = text
  toastEl.dataset.kind = kind || 'ok'
  toastEl.hidden = false
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastEl.hidden = true }, 2600)
}

/** Los errores se comparan por código: el texto está traducido (`errorText`). */
const humanError = (e) => errorText(lang, e)

function el (tag, props = {}, children = []) {
  const n = Object.assign(document.createElement(tag), props)
  for (const c of [].concat(children)) if (c) n.append(c)
  return n
}

const hostOf = (u) => { try { return new URL(u).hostname } catch { return '' } }

/**
 * UN SITIO ESCRITO A MANO, en la forma en que lo guarda la bóveda.
 *
 * Se acepta pegar la dirección entera (`https://banco.com.ec/entrar`) porque es lo que
 * uno tiene en el portapapeles, y se queda el dominio. El `*.` de delante se respeta: es
 * un patrón válido para el emparejamiento (§4.2) y va en el propio campo para que se sepa
 * que se puede — aunque casi nunca haga falta, porque un dominio a secas YA cubre sus
 * subdominios. Lo único que cambia el comodín es que deja fuera el último recurso por
 * dominio registrable: con `vault.dotrino.com` guardado, `pass.dotrino.com` empareja
 * igual (son del mismo dominio); con `*.vault.dotrino.com`, no.
 *
 * Devuelve '' si no hay dominio dentro, y entonces no se añade nada: un sitio que no
 * puede emparejar con ninguna página sería una fila que no hace nada y nadie lo sabría.
 */
function normalizarSitio (texto) {
  let t = String(texto || '').trim().toLowerCase()
  if (!t) return ''
  const comodin = t.startsWith('*.')
  if (comodin) t = t.slice(2)
  if (!t.includes('://')) t = 'https://' + t
  const h = hostOf(t)
  // Vale cualquier host que el navegador sepa leer, **también sin punto**: `localhost`,
  // el `nas` de tu casa o una IP son sitios de verdad. Exigir un punto los dejaba fuera.
  if (!h) return ''
  return comodin ? `*.${h}` : h
}

/** El dominio de un patrón, para poder abrir ese sitio: `*.x.com` → `x.com`. */
const dominioDe = (patron) => String(patron || '').replace(/^\*\./, '')

// --- la dirección: qué se está mirando ---------------------------------------
//
// Va en el `#fragment` para que un refresco no pierda la ficha abierta, y porque una
// pestaña de la extensión no tiene ruta propia que gastar.

function ruta () {
  const p = new URLSearchParams(location.hash.slice(1))
  return { site: p.get('site') || '', id: p.get('id') || '', only: p.get('only') || '', view: p.get('view') || '', address: p.get('address') || '' }
}

function ir ({ site, id, only, view }) {
  const p = new URLSearchParams()
  if (view) p.set('view', view)
  if (site) p.set('site', site)
  if (id) p.set('id', id)
  if (only) p.set('only', only)
  location.hash = p.toString()
}

// --- la lista ----------------------------------------------------------------

/**
 * DÓNDE HAY ALGO GUARDADO, y un buscador para llegar a un registro concreto.
 *
 * **Sigue sin haber «verlos todos»**, y no es un descuido: la bóveda no entrega su lista
 * entera a nadie (`REMOTE_OPS` no lleva `list`). Lo que sí entrega son los DOMINIOS
 * (`sites`, 2026-08-29): el dominio ya viaja en claro y con él se abre cada sitio como si
 * se viniera de su página, que es lo que evita un buscador en blanco donde hay que
 * adivinar qué escribir.
 */
async function renderList () {
  const { site, only } = ruta()

  const ctx = () => ({ lang, ask, toast, humanError, pre: 'manager', onChanged: render })

  const buscador = el('input', {
    type: 'search',
    placeholder: t(lang, 'searchRecords'),
    autocomplete: 'off',
  })
  buscador.dataset.testid = 'manager-search'

  // DE QUÉ BÓVEDA se está hablando. Un perfil es una bóveda (§3.3) y aquí se administra
  // todo, así que sin esta barra la pantalla no dice de quién es lo que enseña. Añadir un
  // perfil no está: pide emparejar, y ese flujo vive en el popup.

  const lista = el('ul', { className: 'entries' })
  const titulo = el('h2')
  const nota = el('p', { className: 'hint' })
  const tituloSitios = el('h2', { textContent: t(lang, 'whereLabel'), hidden: true })
  const sitios = el('div', { className: 'domains' })

  // El sitio con el que se opera: el dominio que se pulsó arriba, o el de donde se vino.
  // Hace falta para la casilla de predeterminada y para borrar, que son por sitio.
  const sitioActivo = () => (only && only !== '*' ? `https://${dominioDe(only)}/` : site)



  /**
   * La MISMA tarjeta del popup (dueño, 2026-08-29: *«todas las acciones del modal
   * principal deberían estar presentes en el manager, menos fill»*). Rellenar no se pasa:
   * es de la página que tienes delante, y aquí no hay ninguna.
   */
  const fila = (e, porDefecto) => entryCard(ctx(), e, {
    isDefault: e.id === porDefecto,
    onEdit: (x) => ir({ site, id: x.id, only }),
    onRenamed: () => render(),
    onDefault: async (x, marcada) => {
      try { await ask('default-set', { url: sitioActivo(), id: marcada ? x.id : null }); render() }
      catch (err) { toast(humanError(err), 'error') }
    },
    onDelete: async (x) => {
      try { await ask('remove', { id: x.id, url: sitioActivo() }); toast(t(lang, 'deleted')); render() }
      catch (err) { toast(humanError(err), 'error') }
    },
  })

  const pintar = async (items, cabecera, vacio) => {
    titulo.textContent = cabecera
    // Cuál es la predeterminada es del SITIO, así que se pregunta por el que se esté
    // mirando: sin esto la casilla saldría siempre en blanco.
    const porDefecto = await ask('default-get', { url: sitioActivo() }).catch(() => null)
    lista.replaceChildren(...[...items].sort(byName).map(e => fila(e, porDefecto)))
    nota.textContent = items.length ? '' : vacio
    nota.hidden = !!items.length
  }

  // Los ACCESOS con usuario y contraseña no se administran aquí: son aparatos de la cuenta,
  // no contraseñas guardadas, y su puerta está en la página del perfil (dueño, 2026-09-21:
  // «entrar con usuario y contraseña es algo que no se hace en la bóveda normal»).
  view.replaceChildren(buscador, tituloSitios, sitios, titulo, lista, nota)

  /**
   * Los dominios donde hay algo. Pulsar uno es lo mismo que abrir el gestor desde esa
   * página: se listan sus registros — y, con ellos, los que sirven en cualquier sitio,
   * porque en esa página también servirían.
   */
  const pintarSitios = async () => {
    let hay = []
    try { hay = await ask('sites') } catch (_) { return }
    if (!hay.length) return
    tituloSitios.hidden = false
    sitios.replaceChildren(...hay.map(({ site: d, count }) => {
      const b = el('button', {
        className: 'domain' + ((d || '*') === only ? ' on' : ''),
        type: 'button',
      })
      b.dataset.testid = `manager-site-${d || 'anywhere'}`
      b.append(
        el('span', { textContent: d || t(lang, 'noSite') }),
        el('span', { className: 'n', textContent: String(count) }),
      )
      // Sin dominio propio no hay página a la que ir: esas entradas salen en cualquiera,
      // así que se enseñan con el sitio que ya se estaba mirando.
      // Se lleva el PATRÓN, no el dominio a secas: `*.empresa.com` y `empresa.com` son
      // dos formas de archivar y cada una tiene su botón, así que cada una filtra la suya.
      b.onclick = () => ir({ site: d ? `https://${dominioDe(d)}/` : site, only: d || '*' })
      return b
    }))
  }

  /**
   * LOS REGISTROS DE UN DOMINIO, los archivados ahí y solo esos.
   *
   * No es lo mismo que «lo que serviría en esa página», y confundirlas fue un fallo real
   * (dueño, 2026-08-29): *«presiono dotrino.com, dice 1 en el botón pero no filtra los
   * resultados»*. `find` contesta lo segundo — y por eso mete también **todo lo que no
   * tiene sitio**, que vale en cualquier parte, y los de un subdominio hermano. El número
   * del botón contesta lo primero. Las dos son ciertas y no coinciden.
   *
   * En un gestor manda la primera: pulsar `dotrino.com` es «enséñame los de dotrino.com».
   * La otra lectura se queda donde le toca — el popup, que sí habla de la página que
   * tienes delante.
   */
  const soloDe = async () => {
    const donde = only === '*' ? (site || 'https://dotrino.invalid/') : site
    const todos = await ask('find', { url: donde })
    const suyos = only === '*'
      ? todos.filter(e => !e.sites?.length)
      : todos.filter(e => (e.sites || []).includes(only))
    await pintar(suyos, only === '*' ? t(lang, 'noSite') : only, t(lang, 'noneHere'))
  }

  const delSitio = async () => {
    if (only) {
      titulo.hidden = false
      lista.hidden = false
      try { await soloDe() } catch (e) { nota.hidden = false; nota.textContent = humanError(e) }
      return
    }
    if (!site) {
      // Sin sitio de partida no hay nada que listar: se elige un dominio de arriba, o se
      // busca. Una sección de registros vacía solo estorbaría.
      titulo.hidden = true
      lista.hidden = true
      nota.hidden = false
      nota.textContent = t(lang, 'searchRest')
      return
    }
    titulo.hidden = false
    lista.hidden = false
    try {
      await pintar(await ask('find', { url: site }), `${t(lang, 'onThisSite')} · ${hostOf(site)}`, t(lang, 'noneHere'))
      if (!nota.hidden) return
      nota.hidden = false
      nota.textContent = t(lang, 'searchRest')
    } catch (e) { nota.hidden = false; nota.textContent = humanError(e) }
  }

  // Buscar es de la bóveda entera y exige dos letras (§2): no es la lista disfrazada.
  let timer
  buscador.oninput = () => {
    clearTimeout(timer)
    const q = buscador.value.trim()
    timer = setTimeout(async () => {
      if (q.length < 2) { sitios.hidden = false; tituloSitios.hidden = !sitios.children.length; return delSitio() }
      sitios.hidden = true
      tituloSitios.hidden = true
      try {
        await pintar(await ask('search', { q }), t(lang, 'all'), t(lang, 'noneFound'))
      } catch (e) { nota.hidden = false; nota.textContent = humanError(e) }
    }, 250)
  }

  await delSitio()
  buscador.focus()
  await pintarSitios()
}

// --- la ficha de un registro --------------------------------------------------

/** El nombre visible de una clave. La pieza es de `i18n`: la comparte con el popup. */
const nombreDe = (key, label) => fieldLabel(lang, key, label)

/**
 * LAS FILAS de una ficha, a partir de lo público.
 *
 * De la vista pública salen los NOMBRES de lo que lleva dentro y cuáles son privados
 * (§4.0.2), que es todo lo que hace falta para dibujar la ficha. Los valores se piden
 * después, y **solo los públicos**.
 */
function filasDe (vista) {
  const keys = Array.isArray(vista.fieldKeys) ? vista.fieldKeys : []
  const privadas = new Set(Array.isArray(vista.privateKeys) ? vista.privateKeys : [])
  const filas = []

  for (const k of BUILTIN) {
    const hay = k === 'notes' ? vista.hasNotes : keys.includes(k)
    if (!hay) continue
    filas.push({
      key: k, label: kindLabel(lang, k), kind: null, builtin: true,
      priv: k === 'notes' ? true : privadas.has(k) || SIEMPRE_PRIVADOS.includes(k),
      fijoPriv: SIEMPRE_PRIVADOS.includes(k) || k === 'username',
      valor: '', quitada: false, nueva: false,
    })
  }
  for (const k of keys) {
    if (BUILTIN.includes(k)) continue
    filas.push({
      key: k, label: nombreDe(k), kind: k.startsWith('label:') ? null : k, builtin: false,
      priv: privadas.has(k), fijoPriv: false,
      valor: '', quitada: false, nueva: false,
    })
  }
  return filas
}

async function renderRecord (id) {
  const { site, only } = ruta()
  const volver = el('button', { type: 'button', textContent: `‹ ${t(lang, 'backToList')}` })
  volver.dataset.testid = 'manager-back'
  volver.onclick = () => ir({ site, only })
  const migas = el('div', { className: 'crumbs' }, [volver])

  view.replaceChildren(migas, el('p', { className: 'hint', textContent: t(lang, 'waiting') }))

  let vista
  try {
    vista = await ask('entry-view', { id, url: site })
  } catch (e) {
    view.replaceChildren(migas, el('p', { className: 'error', textContent: humanError(e) }))
    return
  }


  const filas = filasDe(vista)
  // Los sitios donde vale este registro. Sin ninguno vale en cualquiera, que es lo que
  // la ausencia de sitios ha significado siempre (§4.2).
  const sitios0 = [...(vista.sites || [])]
  let sitios = [...sitios0]
  // Las filas nuevas se numeran solas. Por el índice del array no vale: quitar una fila de
  // arriba renumeraría a las de abajo, y con ellas su sitio en el DOM.
  let nuevas = 0
  const nombre0 = vista.hint || ''
  let nombre = nombre0
  // Lo que dice el resumen de cada fila: `same`, `changed` o `new`. Se rellena solo, en
  // cuanto el usuario escribe, y es lo único que sabemos de un valor privado.
  const estado = new Map()

  // --- los valores PÚBLICOS, que son los únicos que se piden ---------------------
  const publicas = filas.filter(f => !f.priv).map(f => f.key)
  if (publicas.length) {
    try {
      const abierta = await ask('get', { id, keys: publicas })
      const campos = (() => {
        if (Array.isArray(abierta.fields)) return abierta.fields
        try { return JSON.parse(abierta.fields || '[]') } catch { return [] }
      })()
      for (const f of filas) {
        if (f.priv) continue
        if (f.builtin) { f.valor = String(abierta[f.key] || ''); continue }
        const c = campos.find(x => (x.kind || (x.label ? `label:${x.label}` : 'other')) === f.key)
        if (c) { f.valor = String(c.value || ''); if (c.label) f.label = c.label }
      }
    } catch (e) { toast(humanError(e), 'error') }
  }
  const original = new Map(filas.map(f => [f.key, f.valor]))

  // --- pintar --------------------------------------------------------------------
  const lista = el('ul', { className: 'values' })
  const guardar = el('button', { className: 'primary', textContent: t(lang, 'saveChanges'), disabled: true })
  guardar.dataset.testid = 'manager-save'

  const cajaNombre = el('input', { type: 'text', value: nombre, placeholder: t(lang, 'entryName') })
  cajaNombre.dataset.testid = 'manager-name'
  cajaNombre.oninput = () => { nombre = cajaNombre.value; sync() }

  /** ¿Hay algo que guardar? Con un valor privado, lo dice el resumen y nada más. */
  function sucio () {
    if (nombre.trim() !== nombre0.trim()) return true
    if (sitios.length !== sitios0.length || sitios.some((x, i) => x !== sitios0[i])) return true
    return filas.some(f => {
      if (f.quitada) return true
      if (f.nueva) return !!(f.valor.trim() && (f.label.trim() || f.kind))
      if (f.priv !== f.priv0) return true
      if (!f.valor) return false
      if (f.priv) return estado.get(f.key) !== 'same'
      return f.valor !== original.get(f.key)
    })
  }
  for (const f of filas) f.priv0 = f.priv

  function sync () { guardar.disabled = !sucio() }

  /** Lo escrito contra lo guardado, por resúmenes. Sin abrir nada y sin autorizaciones. */
  let dTimer
  function pedirDiff () {
    clearTimeout(dTimer)
    dTimer = setTimeout(async () => {
      const pares = filas
        .filter(f => !f.nueva && !f.quitada && f.valor)
        .map(f => ({ key: f.key, value: f.valor }))
      if (!pares.length) return
      try {
        const r = await ask('entry-diff', { id, url: site, pairs: pares })
        for (const [k, v] of Object.entries(r || {})) estado.set(k, v)
        // Se repintan SOLO las etiquetas. Volver a dibujar las filas le quitaría el foco
        // al campo donde se está escribiendo, que es exactamente cuando esto ocurre.
        for (const r2 of refrescos) r2()
        sync()
      } catch (_) { /* sin resumen la fila se queda sin etiqueta, y no pasa nada */ }
    }, 300)
  }

  // Las etiquetas de cada fila, para poder refrescarlas sin volver a dibujarlo todo.
  const refrescos = []

  function filaValor (f) {
    const ref = f.key || `new-${f.nid}`
    const li = el('li', { className: 'value' + (f.quitada ? ' gone' : '') })
    li.dataset.testid = `manager-row-${ref}`

    const caja = el('input', {
      type: 'text',
      value: f.valor,
      placeholder: f.priv && !f.nueva ? t(lang, 'replaceHint') : t(lang, 'valuePh'),
      disabled: f.quitada,
    })
    caja.dataset.testid = `manager-value-${ref}`
    caja.oninput = () => {
      f.valor = caja.value
      f.tocada = true
      estado.delete(f.key)
      sync(); pedirDiff(); pintarEtiqueta()
    }

    const tag = el('span', { className: 'tag', hidden: true })
    tag.dataset.testid = `manager-tag-${ref}`
    function pintarEtiqueta () {
      // Solo en lo que se ha tocado. Una fila recién cargada dice «igual» por definición
      // —trae su propio valor—, y decirlo en las siete es ruido que tapa el que importa.
      const s = f.nueva
        ? (f.valor ? 'new' : null)
        : (f.tocada && f.valor ? estado.get(f.key) : null)
      tag.hidden = !s || s === 'same'
      if (s === 'same') { tag.hidden = false; tag.className = 'tag same'; tag.textContent = t(lang, 'fieldSame') }
      else if (s) { tag.className = 'tag' + (s === 'changed' ? ' changed' : ''); tag.textContent = t(lang, s === 'changed' ? 'fieldChanged' : 'fieldNew') }
    }
    pintarEtiqueta()
    refrescos.push(pintarEtiqueta)

    const marca = el('input', { type: 'checkbox', checked: f.priv, disabled: f.fijoPriv || f.quitada })
    marca.dataset.testid = `manager-private-${ref}`
    marca.onchange = () => { f.priv = marca.checked; sync() }
    const etiquetaMarca = el('label', { className: 'mark', title: t(lang, 'private') }, [
      marca, el('span', { textContent: t(lang, 'private') }),
    ])
    etiquetaMarca.hidden = f.fijoPriv

    const x = el('button', {
      className: 'x', type: 'button',
      textContent: f.quitada ? '↺' : '✕',
      title: f.quitada ? t(lang, 'undoRemove') : t(lang, 'removeField'),
    })
    x.setAttribute('aria-label', x.title)
    x.dataset.testid = `manager-remove-${ref}`
    x.onclick = () => {
      if (f.nueva && !f.quitada) { filas.splice(filas.indexOf(f), 1); paint(); sync(); return }
      f.quitada = !f.quitada
      paint(); sync()
    }

    if (f.nueva) {
      li.className = 'newrow'
      const tipo = el('select')
      tipo.dataset.testid = `manager-kind-new-${f.nid}`
      tipo.append(el('option', { value: '', textContent: t(lang, 'kindNone') }))
      // Los de siempre que este registro NO tiene: añadir una contraseña a una ficha de
      // datos es tan normal como añadirle un teléfono.
      for (const k of BUILTIN) {
        if (filas.some(o => o !== f && o.key === k)) continue
        tipo.append(el('option', { value: `!${k}`, textContent: kindLabel(lang, k) }))
      }
      for (const k of KINDS) tipo.append(el('option', { value: k, textContent: kindLabel(lang, k) }))
      tipo.value = f.builtin ? `!${f.key}` : (f.kind || '')
      tipo.onchange = () => {
        const v = tipo.value
        if (v.startsWith('!')) {
          f.builtin = true; f.key = v.slice(1); f.kind = null
          f.label = kindLabel(lang, f.key)
          f.fijoPriv = SIEMPRE_PRIVADOS.includes(f.key) || f.key === 'username'
          f.priv = SIEMPRE_PRIVADOS.includes(f.key)
        } else {
          f.builtin = false; f.key = ''; f.kind = v || null
          if (v) f.label = kindLabel(lang, v)
        }
        paint(); sync()
      }
      const etiqueta = el('input', {
        type: 'text', value: f.label, placeholder: t(lang, 'labelPh'), disabled: f.builtin,
      })
      etiqueta.dataset.testid = `manager-label-new-${f.nid}`
      etiqueta.oninput = () => { f.label = etiqueta.value; sync() }
      li.append(tipo, etiqueta, caja, etiquetaMarca, x)
      return li
    }

    li.append(el('span', { className: 'k', textContent: f.label, title: f.label }), caja, tag, etiquetaMarca, x)
    return li
  }

  const anadir = el('button', { className: 'ghost', textContent: `+ ${t(lang, 'addValue')}` })
  anadir.dataset.testid = 'manager-add'
  anadir.onclick = () => {
    filas.push({ key: '', label: '', kind: null, builtin: false, priv: false, priv0: false, fijoPriv: false, valor: '', quitada: false, nueva: true, nid: nuevas++ })
    paint()
    view.querySelector('.newrow input')?.focus()
  }

  function paint () {
    refrescos.length = 0
    lista.replaceChildren(...filas.map(f => filaValor(f)))
  }
  paint()

  /**
   * LOS SITIOS DONDE VALE, editables (dueño, 2026-08-29).
   *
   * Una lista enumerada, porque es lo que una persona puede leer y comprobar: «esta
   * cuenta vale en estos sitios». El comodín se admite escrito —el emparejamiento lo
   * entiende—, pero no es lo normal y por eso no hay un control para ponerlo: un dominio
   * a secas ya cubre sus subdominios, y decirlo es más útil que ofrecer el asterisco.
   */
  const listaSitios = el('div', { className: 'sites' })
  const cajaSitio = el('input', { type: 'text', placeholder: t(lang, 'sitePh'), autocomplete: 'off' })
  cajaSitio.dataset.testid = 'manager-site-input'
  const errSitio = el('p', { className: 'error', hidden: true })

  const anadirSitio = () => {
    const limpio = normalizarSitio(cajaSitio.value)
    if (!limpio) {
      errSitio.textContent = t(lang, 'badSite')
      errSitio.hidden = false
      return
    }
    errSitio.hidden = true
    cajaSitio.value = ''
    if (!sitios.includes(limpio)) { sitios.push(limpio); pintarSitios() }
    sync()
  }

  const masSitio = el('button', { className: 'ghost', textContent: `+ ${t(lang, 'addSite')}` })
  masSitio.dataset.testid = 'manager-site-add'
  masSitio.onclick = anadirSitio
  cajaSitio.onkeydown = (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); anadirSitio() } }

  const notaSitios = el('p', { className: 'hint' })

  function pintarSitios () {
    listaSitios.replaceChildren(...sitios.map((d) => {
      const chip = el('span', { className: 'site-chip' })
      chip.dataset.testid = `manager-site-chip-${d}`
      const x = el('button', { className: 'x', type: 'button', textContent: '✕', title: t(lang, 'removeSite') })
      x.setAttribute('aria-label', `${t(lang, 'removeSite')}: ${d}`)
      x.dataset.testid = `manager-site-remove-${d}`
      x.onclick = () => { sitios = sitios.filter(o => o !== d); pintarSitios(); sync() }
      chip.append(el('span', { textContent: d }), x)
      return chip
    }))
    // Sin ninguno vale en cualquier sitio: eso no es un hueco, es una decisión, y hay que
    // decirlo. Con alguno, lo que hay que saber es que el dominio ya trae sus subdominios.
    notaSitios.textContent = t(lang, sitios.length ? 'sitesCover' : 'sitesAnywhere')
  }
  pintarSitios()

  const cancelar = el('button', { className: 'ghost', textContent: t(lang, 'cancel') })
  cancelar.dataset.testid = 'manager-cancel'
  cancelar.onclick = () => ir({ site, only })

  guardar.onclick = async () => {
    guardar.disabled = true
    try {
      await aplicar({ id, site, filas, original, estado, nombre, nombre0, sitios, sitios0 })
      toast(t(lang, 'saved'))
      ir({ site, only })
    } catch (e) {
      toast(humanError(e), 'error')
      sync()
    }
  }

  view.replaceChildren(
    migas,
    el('div', { className: 'field-name' }, [
      el('label', { textContent: t(lang, 'entryName'), htmlFor: '' }),
      cajaNombre,
    ]),
    el('h2', { textContent: t(lang, 'values') }),
    lista,
    anadir,
    el('h2', { textContent: t(lang, 'sites') }),
    listaSitios,
    el('div', { className: 'siteadd' }, [cajaSitio, masSitio]),
    errSitio,
    notaSitios,
    el('div', { className: 'actions' }, [guardar, cancelar, el('span', { className: 'sp' })]),
  )
  pedirDiff()
}

/**
 * DE LAS FILAS A UN `patch`, y de ahí a la bóveda. Una sola escritura para toda la ficha.
 *
 * Antes de escribir se vuelve a preguntar por resúmenes: lo que el usuario tecleó igual a
 * lo que ya había NO se escribe. Es lo que hace que reescribir una contraseña con la
 * misma no cuente como un cambio.
 */
async function aplicar ({ id, site, filas, original, estado, nombre, nombre0, sitios, sitios0 }) {
  const escritas = filas.filter(f => !f.quitada && f.valor && !f.nueva).map(f => ({ key: f.key, value: f.valor }))
  let dice = estado
  if (escritas.length) {
    try {
      const r = await ask('entry-diff', { id, url: site, pairs: escritas })
      dice = new Map([...estado, ...Object.entries(r || {})])
    } catch (_) { /* sin resumen se escribe lo tecleado, que es lo que el usuario quiso */ }
  }

  const changes = {}
  const fields = []
  const removeFields = []

  if (nombre.trim() !== nombre0.trim()) changes.name = nombre.trim()
  // La lista entera, no un «añade este»: aquí el usuario la está escribiendo.
  if (sitios.length !== sitios0.length || sitios.some((x, i) => x !== sitios0[i])) changes.sites = sitios

  for (const f of filas) {
    if (f.quitada) {
      if (!f.nueva && f.key) removeFields.push(f.key)
      continue
    }
    if (f.nueva) {
      const valor = f.valor.trim()
      if (!valor) continue
      if (f.builtin) { changes[f.key] = valor; continue }
      const label = (f.label || (f.kind ? kindLabel(lang, f.kind) : '')).trim()
      if (!label && !f.kind) continue
      fields.push({ label, value: valor, ...(f.kind ? { kind: f.kind } : {}), private: !!f.priv })
      continue
    }

    const cambiaValor = f.valor && dice.get(f.key) !== 'same' &&
      (f.priv || f.valor !== original.get(f.key))
    const cambiaMarca = f.priv !== f.priv0

    if (f.builtin) {
      if (cambiaValor) changes[f.key] = f.valor
      // Los de siempre no llevan marca que cambiar: o son privados por lo que son, o
      // —el usuario— es el nombre visible de la entrada y no se esconde.
      continue
    }
    if (!cambiaValor && !cambiaMarca) continue
    // Sin `value` la bóveda deja el valor como estaba: así se cambia la marca de un campo
    // privado sin tenerlo delante, que es justo lo que el gestor no puede pedir.
    fields.push({
      label: f.key.startsWith('label:') ? f.key.slice(6) : f.label,
      ...(f.kind ? { kind: f.kind } : {}),
      ...(cambiaValor ? { value: f.valor } : {}),
      private: !!f.priv,
    })
  }

  if (fields.length) changes.fields = fields
  if (removeFields.length) changes.removeFields = removeFields
  if (!Object.keys(changes).length) return
  await ask('patch', { id, changes })
}

// --- entrar con usuario y contraseña ------------------------------------------
//
// `docs/temporary-access.md`. Pantalla ADMINISTRATIVA (CONVENCIONES §5.1): la lista con lo
// que hace falta para operar y los botones que operan. Lo único que se explica es lo que
// sin decirlo llevaría a un error — que esta bóveda se apaga cuando cierras la pestaña —,
// y eso no es documentación: es un aviso.

async function renderLogins () {
  // CUALQUIER permiso del acta, todos por igual (dueño, 2026-09-21). La lista sale del pilar,
  // no de aquí: un permiso nuevo aparece solo.
  const caps = DEVICE_CAPS
  const elegidos = new Set(['sign', 'read', 'store'])

  const volver = el('button', { className: 'link', textContent: t(lang, 'lgBack') })
  // Se llega desde la página del perfil, y se vuelve ahí.
  volver.onclick = () => { location.href = 'profile.html' }

  const lista = el('div', { className: 'logins' })
  const msg = el('p', { className: 'hint' })

  const pinta = async () => {
    lista.replaceChildren()
    let filas = []
    try { filas = await logins.listLogins() } catch (e) { msg.textContent = humanError(e); return }
    if (!filas.length) { lista.append(el('p', { className: 'hint', textContent: t(lang, 'lgNone') })); return }
    for (const l of filas) lista.append(fila(l))
  }

  const fila = (l) => {
    const espera = l.blockedUntil > Date.now() ? Math.ceil((l.blockedUntil - Date.now()) / 1000) : 0
    const quien = el('div', {}, [
      el('strong', { textContent: l.user }),
      el('div', { className: 'hint', textContent: `${l.address || ''} · ${l.deviceId || '????-????'}` }),
      el('div', {
        className: 'hint',
        textContent: [
          t(lang, 'lgOpen', l.sessions.length),
          l.label || '',
          espera ? t(lang, 'lgWait', espera) : ''
        ].filter(Boolean).join(' · ')
      })
    ])

    const cerrar = el('button', { className: 'btn ghost sm', textContent: t(lang, 'lgCloseAll'), disabled: !l.sessions.length })
    cerrar.onclick = () => correr(() => logins.closeLogin({ user: l.user }))
    const desbloquear = el('button', { className: 'btn ghost sm', textContent: t(lang, 'lgUnblock'), disabled: !espera })
    desbloquear.onclick = () => correr(() => logins.unblockLogin({ user: l.user }))

    const vieja = el('input', { type: 'password', placeholder: t(lang, 'lgOld'), autocomplete: 'off' })
    const nueva = el('input', { type: 'password', placeholder: t(lang, 'lgNew'), autocomplete: 'new-password' })
    const cambiar = el('button', { className: 'btn ghost sm', textContent: t(lang, 'lgPasswd') })
    const formPass = el('div', { className: 'lg-pass', hidden: true }, [vieja, nueva,
      el('button', { className: 'btn sm', textContent: t(lang, 'lgPasswd'), onclick: () => correr(async () => {
        if (nueva.value.length < 12) throw Object.assign(new Error(t(lang, 'lgShort')), { code: 'weak-password' })
        await logins.passwdLogin({ user: l.user, oldPassword: vieja.value, newPassword: nueva.value })
        vieja.value = ''; nueva.value = ''; formPass.hidden = true
      }) })])
    cambiar.onclick = () => { formPass.hidden = !formPass.hidden }

    // La confirmación es de esta pantalla: nada de `confirm()` (CONVENCIONES §5).
    const seguro = el('div', { className: 'lg-sure', hidden: true }, [
      el('span', { textContent: t(lang, 'lgRemoveSure', l.user) }),
      el('button', { className: 'btn sm danger', textContent: t(lang, 'lgRemove'),
        onclick: () => correr(() => logins.removeLogin({ user: l.user })) }),
      el('button', { className: 'btn ghost sm', textContent: t(lang, 'cancel'), onclick: () => { seguro.hidden = true } })
    ])
    const quitar = el('button', { className: 'btn ghost sm danger', textContent: t(lang, 'lgRemove') })
    quitar.onclick = () => { seguro.hidden = false }

    return el('div', { className: 'login-row' }, [
      quien,
      el('div', { className: 'row' }, [cerrar, desbloquear, cambiar, quitar]),
      formPass,
      seguro
    ])
  }

  const correr = async (fn) => {
    msg.textContent = ''
    try { await fn(); await pinta() }
    catch (e) { msg.textContent = humanError(e) }
  }

  // --- alta ---
  const usuario = el('input', { placeholder: t(lang, 'lgUser'), autocomplete: 'off' })
  usuario.dataset.testid = 'lg-user'
  const equipo = el('input', { placeholder: t(lang, 'lgFor'), autocomplete: 'off' })
  const pass = el('input', { type: 'password', placeholder: t(lang, 'lgPass'), autocomplete: 'new-password' })
  pass.dataset.testid = 'lg-pass'
  const pass2 = el('input', { type: 'password', placeholder: t(lang, 'lgPass2'), autocomplete: 'new-password' })
  const permisos = el('div', { className: 'caps' }, caps.map((c) => {
    const b = el('button', { className: 'cap' + (elegidos.has(c) ? ' on' : ''), textContent: t(lang, 'cap_' + c) })
    b.dataset.cap = c
    b.onclick = () => {
      if (elegidos.has(c)) elegidos.delete(c); else elegidos.add(c)
      b.className = 'cap' + (elegidos.has(c) ? ' on' : '')
    }
    return b
  }))
  const crear = el('button', { className: 'btn', textContent: t(lang, 'lgCreate') })
  crear.dataset.testid = 'lg-add'
  crear.onclick = () => correr(async () => {
    if (pass.value.length < 12) throw Object.assign(new Error(t(lang, 'lgShort')), { code: 'weak-password' })
    if (pass.value !== pass2.value) throw Object.assign(new Error(t(lang, 'lgMismatch')), { code: 'mismatch' })
    const r = await logins.addLogin({
      user: usuario.value.trim().toLowerCase(),
      password: pass.value,
      label: equipo.value.trim(),
      caps: [...elegidos]
    })
    usuario.value = ''; equipo.value = ''; pass.value = ''; pass2.value = ''
    toast(t(lang, 'lgMade', r.address || ''))
  })

  // --- ser bóveda ---
  //
  // UNA sola forma, y abre una pestaña (dueño, 2026-09-19). Aquí se administra; atender es
  // otra cosa y tiene su propia ventana, porque lo que está encendido tiene que verse — y
  // porque cerrarla es apagarlo, sin estado escondido que ir a buscar.
  const atender = el('button', { className: 'btn ghost', textContent: t(lang, 'vtOpenTab') })
  atender.dataset.testid = 'lg-serve'
  atender.onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('src/vault-tab.html') })

  view.replaceChildren(
    volver,
    el('h2', { textContent: t(lang, 'lgTitle') }),
    el('p', { className: 'hint', textContent: t(lang, 'lgIntro') }),
    lista,
    el('div', { className: 'lg-form' }, [usuario, equipo, pass, pass2,
      el('p', { className: 'hint', textContent: t(lang, 'lgCan') }), permisos, crear]),
    el('div', { className: 'row' }, [atender]),
    // EL AVISO no se esconde detrás de nada: sin él, alguien deja esto «atendiendo» y se
    // encuentra con que desde el otro equipo no entra (§5.1: una advertencia no es una
    // explicación).
    el('p', { className: 'hint warn', textContent: t(lang, 'lgWorker') }),
    msg
  )
  await pinta()
}

// --- ENTRAR con usuario y contraseña ------------------------------------------

/**
 * LA OTRA MITAD: entrar en una cuenta tuya desde ESTE navegador, que no la conoce.
 *
 * Se escribe `nombre@AB12-CD34-EF56` y la contraseña; al volver, el gestor es un aparato
 * de esa cuenta. La contraseña no viaja —viajan los mensajes de OPAQUE— y la conversación
 * corre en esta página, no en el service worker, por lo mismo de siempre: el WASM vive en
 * la página sandbox y un worker no puede sostener un socket.
 *
 * Está en el GESTOR y no en el popup a propósito: el popup se cierra al pulsar fuera, y
 * eso a mitad de un inicio de sesión deja la cuenta a medias en la bóveda. Misma razón por
 * la que atender abre una pestaña.
 */
async function renderLogin () {
  const volver = el('button', { className: 'link', textContent: t(lang, 'lgBack') })
  volver.onclick = () => ir({})

  const dir = el('input', {
    type: 'text', className: 'lg-addr', placeholder: 'nombre@AB12-CD34-EF56',
    autocomplete: 'username', spellcheck: false, autocapitalize: 'none'
  })
  dir.dataset.testid = 'login-address'
  const pass = el('input', { type: 'password', placeholder: t(lang, 'inPassword'), autocomplete: 'current-password' })
  pass.dataset.testid = 'login-password'

  // «Recordar» NACE APAGADO, y es lo correcto en un equipo prestado: sin él la cuenta vive
  // en memoria y se va al cerrar. Marcarlo tiene que ser un acto, no un valor heredado.
  const recordar = el('input', { type: 'checkbox' })
  recordar.dataset.testid = 'login-remember'
  const msg = el('p', { className: 'hint' })

  const entrar = el('button', { className: 'btn', textContent: t(lang, 'inEnter') })
  entrar.dataset.testid = 'login-go'
  entrar.onclick = async () => {
    msg.className = 'hint'
    if (!dir.value.trim() || !pass.value) { msg.textContent = t(lang, 'inNeed'); return }
    entrar.disabled = true
    msg.textContent = t(lang, 'inGoing')
    try {
      const r = await logins.enterWithPassword({
        address: dir.value.trim(),
        password: pass.value,
        remember: recordar.checked,
        label: t(lang, 'inLabel')
      })
      // La contraseña se va de la pantalla en cuanto deja de hacer falta.
      pass.value = ''
      msg.textContent = t(lang, 'inDone', r.user || '')
      // El perfil activo cambió: se vuelve a la lista, que ya es la de la cuenta nueva.
      setTimeout(() => ir({}), 900)
    } catch (e) {
      msg.className = 'hint err'
      msg.textContent = humanError(e)
      entrar.disabled = false
    }
  }

  // VOLVER A ENTRAR en una cuenta cuya sesión se cerró: llega con su dirección (la elegiste
  // en el selector de perfiles), así que solo falta la contraseña. Y se puede olvidar.
  const { address } = ruta()
  let olvidar = null
  if (address) {
    dir.value = address
    olvidar = el('button', { className: 'link', textContent: t(lang, 'forgetLogin') })
    olvidar.dataset.testid = 'login-forget'
    olvidar.onclick = async () => {
      try { await ask('login-forget', { address }); ir({}) } catch (e) { msg.className = 'hint err'; msg.textContent = humanError(e) }
    }
  }

  view.replaceChildren(
    el('h2', { textContent: t(lang, 'inTitle') }),
    el('p', { className: 'hint', textContent: t(lang, 'inWhat') }),
    dir,
    pass,
    el('label', { className: 'lg-remember' }, [recordar, el('span', { textContent: t(lang, 'inRemember') })]),
    el('p', { className: 'hint', textContent: t(lang, 'inRememberHint') }),
    el('div', { className: 'row' }, [entrar, volver]),
    // `replaceChildren(null)` pintaría el texto «null»: sin dirección, no va.
    ...(olvidar ? [olvidar] : []),
    msg
  )
  ;(address ? pass : dir).focus()
}

/**
 * CONVERTIR la bóveda propia al formato sellado (`sealed-passwords.md` §2.7): se elige la
 * contraseña de la copia de recuperación y lo guardado pasa al formato nuevo. Sin esto la
 * bóveda no atiende.
 *
 * Desde la 0.16.0 todo mandaba aquí (`#view=convert`) y la pantalla no existía: se caía en
 * la lista y no había forma de convertir desde la interfaz — solo las pruebas, que llaman a
 * `sealed-convert` directamente. Los textos sí estaban.
 */
async function renderConvert () {
  // Una cuenta que ya está convertida, o que no guarda aquí, no tiene nada que hacer en
  // esta pantalla: a la lista.
  try {
    if (!(await ask('sealed-needs'))?.needs) { ir({}); return }
  } catch (e) {
    view.replaceChildren(el('p', { className: 'hint err', textContent: humanError(e) }))
    return
  }

  const pw1 = el('input', { type: 'password', placeholder: t(lang, 'cvPw1'), autocomplete: 'new-password' })
  pw1.dataset.testid = 'convert-pw1'
  const pw2 = el('input', { type: 'password', placeholder: t(lang, 'cvPw2'), autocomplete: 'new-password' })
  pw2.dataset.testid = 'convert-pw2'
  const msg = el('p', { className: 'hint' })
  msg.dataset.testid = 'convert-msg'

  const crear = el('button', { className: 'btn', textContent: t(lang, 'cvGo') })
  crear.dataset.testid = 'convert-go'
  crear.onclick = async () => {
    msg.className = 'hint err'
    if (pw1.value.length < 12) { msg.textContent = t(lang, 'cvShort'); return }
    if (pw1.value !== pw2.value) { msg.textContent = t(lang, 'cvMismatch'); return }
    msg.className = 'hint'
    msg.textContent = t(lang, 'cvWorking')
    crear.disabled = true
    try {
      const r = await ask('sealed-convert', { password: pw1.value })
      // La contraseña se va de la pantalla en cuanto deja de hacer falta.
      pw1.value = ''
      pw2.value = ''
      msg.textContent = t(lang, 'cvDone', r?.entries || 0)
      setTimeout(() => ir({}), 900)
    } catch (e) {
      msg.className = 'hint err'
      msg.textContent = humanError(e)
      crear.disabled = false
    }
  }

  view.replaceChildren(
    el('h2', { textContent: t(lang, 'cvTitle') }),
    el('p', { className: 'hint', textContent: t(lang, 'cvWhy') }),
    // Un aviso, no una explicación (§5.1): sin él se elige una contraseña sin saber que no
    // se puede recuperar.
    el('p', { className: 'hint warn', textContent: t(lang, 'cvWarn') }),
    pw1,
    pw2,
    el('div', { className: 'row' }, [crear]),
    msg
  )
  pw1.focus()
}

// --- arranque -----------------------------------------------------------------

function render () {
  const { id, view } = ruta()
  if (view === 'convert') return renderConvert()
  if (view === 'login') return renderLogin()
  if (view === 'logins') return renderLogins()
  return id ? renderRecord(id) : renderList()
}

window.addEventListener('hashchange', render)

// El idioma lo lleva la barra del ecosistema (§9).
document.addEventListener('dotrino-lang', (ev) => {
  lang = ev.detail?.lang || lang
  render()
})

/**
 * Antes de nada: ¿hay que convertir? Si esta bóveda sigue con el formato viejo, su lista no
 * se puede abrir, así que enseñarla sería enseñar un error por cada fila. Se va derecho a
 * la pantalla que lo arregla.
 */
/** Las pantallas que NO leen la bóveda de contraseñas, y por tanto no hay que convertir. */
const SIN_BOVEDA = ['convert', 'login', 'logins']

async function arrancar () {
  // Solo se desvía lo que va a leer la bóveda. Entrar con usuario y contraseña y
  // administrar los inicios de sesión son de la IDENTIDAD, no de las contraseñas: mandar
  // a convertir a quien llega a un equipo prestado a entrar sería pedirle que arregle una
  // bóveda que todavía no es suya.
  if (!SIN_BOVEDA.includes(ruta().view)) {
    try {
      const r = await ask('sealed-needs')
      if (r?.needs) { ir({ view: 'convert' }); return }
    } catch (_) { /* si no se puede preguntar, se pinta lo de siempre */ }
  }
  render()
}

arrancar()


// La barra, con su selector de perfiles y tu avatar: lo pinta el componente.
wireTopbar(ask)
